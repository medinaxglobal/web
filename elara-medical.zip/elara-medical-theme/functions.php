<?php
/**
 * Elara Medical Theme Functions
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ── THEME SETUP ── */
function elara_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'custom-logo' );
    add_theme_support( 'html5', ['search-form','comment-form','comment-list','gallery','caption','script','style'] );
    add_theme_support( 'wp-block-styles' );
    add_theme_support( 'responsive-embeds' );
    register_nav_menus([
        'primary' => __( 'Primary Menu', 'elara-medical' ),
        'footer'  => __( 'Footer Menu',  'elara-medical' ),
    ]);
}
add_action( 'after_setup_theme', 'elara_setup' );

/* ── ENQUEUE ASSETS ── */
function elara_scripts() {
    wp_enqueue_style( 'elara-fonts',
        'https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;0,800;1,400;1,700&family=Inter:wght@300;400;500;600;700&display=swap',
        [], null );
    wp_enqueue_style( 'elara-main',
        get_template_directory_uri() . '/assets/css/elara.css',
        ['elara-fonts'], '1.0.0' );
    wp_enqueue_script( 'elara-main',
        get_template_directory_uri() . '/assets/js/elara.js',
        [], '1.0.0', true );
    wp_localize_script( 'elara-main', 'elaraData', [
        'siteUrl'  => get_site_url(),
        'themeUrl' => get_template_directory_uri(),
        'ajaxUrl'  => admin_url( 'admin-ajax.php' ),
        'nonce'    => wp_create_nonce( 'elara_nonce' ),
    ]);
}
add_action( 'wp_enqueue_scripts', 'elara_scripts' );

/* ── CONTACT FORM HANDLER ── */
function elara_handle_contact() {
    if ( ! isset( $_POST['elara_nonce'] ) || ! wp_verify_nonce( $_POST['elara_nonce'], 'elara_contact' ) ) {
        wp_send_json_error( ['message' => 'Security check failed.'] );
    }
    $name     = sanitize_text_field( $_POST['name'] ?? '' );
    $email    = sanitize_email( $_POST['email'] ?? '' );
    $phone    = sanitize_text_field( $_POST['phone'] ?? '' );
    $treatment = sanitize_text_field( $_POST['treatment'] ?? '' );
    $message  = sanitize_textarea_field( $_POST['message'] ?? '' );

    if ( empty($name) || empty($email) ) {
        wp_send_json_error( ['message' => 'Please fill in all required fields.'] );
    }

    $to      = get_option('admin_email');
    $subject = 'New Consultation Request — ' . $name;
    $body    = "Name: $name\nEmail: $email\nPhone: $phone\nTreatment: $treatment\nMessage: $message";
    $headers = ['Content-Type: text/plain; charset=UTF-8', "Reply-To: $name <$email>"];
    wp_mail( $to, $subject, $body, $headers );
    wp_send_json_success( ['message' => 'Thank you! We will call you within 2 hours.'] );
}
add_action( 'wp_ajax_elara_contact',        'elara_handle_contact' );
add_action( 'wp_ajax_nopriv_elara_contact', 'elara_handle_contact' );

/* ── REMOVE WORDPRESS ADMIN BAR MARGIN ── */
function elara_remove_admin_bar_style() {
    remove_action( 'wp_head', '_admin_bar_bump_cb' );
}
add_action( 'get_header', 'elara_remove_admin_bar_style' );

/* ── EXCERPT LENGTH ── */
function elara_excerpt_length() { return 20; }
add_filter( 'excerpt_length', 'elara_excerpt_length' );

/* ── CUSTOM POST TYPE: TESTIMONIALS ── */
function elara_register_post_types() {
    register_post_type( 'testimonial', [
        'labels'      => ['name' => 'Testimonials', 'singular_name' => 'Testimonial'],
        'public'      => false,
        'show_ui'     => true,
        'show_in_menu'=> true,
        'supports'    => ['title','editor','thumbnail'],
        'menu_icon'   => 'dashicons-format-quote',
    ]);
    register_post_type( 'before_after', [
        'labels'      => ['name' => 'Before & After', 'singular_name' => 'Before & After'],
        'public'      => false,
        'show_ui'     => true,
        'show_in_menu'=> true,
        'supports'    => ['title','editor','thumbnail'],
        'menu_icon'   => 'dashicons-images-alt2',
    ]);
}
add_action( 'init', 'elara_register_post_types' );

/* ── HELPER: GET SITE PAGE URL BY SLUG ── */
function elara_page_url( $slug ) {
    $page = get_page_by_path( $slug );
    return $page ? get_permalink( $page->ID ) : home_url( '/' . $slug . '/' );
}

/* ── ALLOW SVG UPLOADS ── */
function elara_allow_svg( $mimes ) {
    $mimes['svg'] = 'image/svg+xml';
    return $mimes;
}
add_filter( 'upload_mimes', 'elara_allow_svg' );

/* ── WIDGET AREAS ── */
function elara_widgets_init() {
    register_sidebar([
        'name'          => 'Blog Sidebar',
        'id'            => 'blog-sidebar',
        'before_widget' => '<div class="sidebar-widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>',
    ]);
}
add_action( 'widgets_init', 'elara_widgets_init' );

/* ── CUSTOMIZER ── */
function elara_customizer( $wp_customize ) {
    // Phone Number
    $wp_customize->add_setting( 'elara_phone', ['default' => '0203 123 4567', 'sanitize_callback' => 'sanitize_text_field'] );
    $wp_customize->add_control( 'elara_phone', ['label' => 'Phone Number', 'section' => 'title_tagline', 'type' => 'text'] );
    // Email
    $wp_customize->add_setting( 'elara_email', ['default' => 'hello@elaramedical.co.uk', 'sanitize_callback' => 'sanitize_email'] );
    $wp_customize->add_control( 'elara_email', ['label' => 'Email Address', 'section' => 'title_tagline', 'type' => 'email'] );
    // WhatsApp
    $wp_customize->add_setting( 'elara_whatsapp', ['default' => '447001234567', 'sanitize_callback' => 'sanitize_text_field'] );
    $wp_customize->add_control( 'elara_whatsapp', ['label' => 'WhatsApp Number (no + or spaces)', 'section' => 'title_tagline', 'type' => 'text'] );
}
add_action( 'customize_register', 'elara_customizer' );

/* ── HELPER FUNCTIONS FOR TEMPLATES ── */
function elara_phone()     { return get_theme_mod( 'elara_phone',     '0203 123 4567' ); }
function elara_email()     { return get_theme_mod( 'elara_email',     'hello@elaramedical.co.uk' ); }
function elara_whatsapp()  { return get_theme_mod( 'elara_whatsapp',  '447001234567' ); }
