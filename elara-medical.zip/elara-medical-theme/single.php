<?php get_header(); ?>
<main style="padding:160px 0 80px">
  <div class="container" style="max-width:860px">
    <?php if(have_posts()):while(have_posts()):the_post(); ?>
    <div style="margin-bottom:12px">
      <a href="<?php echo esc_url(elara_page_url('blog')); ?>" style="color:var(--teal);font-size:.82rem;font-weight:600">← Back to Blog</a>
    </div>
    <?php if(has_post_thumbnail()):?>
    <div style="border-radius:var(--radius-xl);overflow:hidden;height:420px;margin-bottom:32px">
      <?php the_post_thumbnail('full',['style'=>'width:100%;height:100%;object-fit:cover']); ?>
    </div>
    <?php endif;?>
    <span style="font-size:.72rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--teal);display:block;margin-bottom:10px"><?php the_category(', '); ?></span>
    <h1 style="font-family:var(--font-display);font-size:clamp(1.8rem,4vw,3rem);color:var(--dark);margin-bottom:14px;line-height:1.2"><?php the_title(); ?></h1>
    <div style="display:flex;align-items:center;gap:16px;margin-bottom:32px;padding-bottom:24px;border-bottom:1px solid var(--border)">
      <span style="font-size:.82rem;color:var(--text3)">By <?php the_author(); ?></span>
      <span style="color:var(--border)">·</span>
      <span style="font-size:.82rem;color:var(--text3)"><?php echo get_the_date(); ?></span>
      <span style="color:var(--border)">·</span>
      <span style="font-size:.82rem;color:var(--text3)"><?php echo ceil(str_word_count(strip_tags(get_the_content()))/200); ?> min read</span>
    </div>
    <div style="color:var(--text2);line-height:1.85;font-size:.97rem"><?php the_content(); ?></div>
    <?php endwhile;endif; ?>
    <div style="margin-top:48px;padding-top:32px;border-top:1px solid var(--border);text-align:center">
      <h3 style="font-family:var(--font-display);font-size:1.5rem;color:var(--dark);margin-bottom:10px">Ready to take the next step?</h3>
      <p style="color:var(--text2);margin-bottom:20px">Book your free consultation with our specialist team.</p>
      <a href="#" class="btn btn-primary btn-lg open-modal">Book Free Consultation</a>
    </div>
  </div>
</main>
<?php get_footer();
