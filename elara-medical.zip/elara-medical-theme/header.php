<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="profile" href="https://gmpg.org/xfn/11">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div id="scroll-progress"></div>

<div id="masthead">
<!-- TOP BAR -->
<div class="topbar">
  <div class="container">
    <div class="tb-left">
      <a href="tel:<?php echo esc_attr(str_replace(' ','',(elara_phone()))); ?>">
        <svg width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81a19.79 19.79 0 01-3.07-8.67A2 2 0 012 3h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.09 11a16 16 0 006.72 6.72l1.36-1.36a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 18.92z"/></svg>
        <?php echo esc_html(elara_phone()); ?>
      </a>
      <a href="mailto:<?php echo esc_attr(elara_email()); ?>">
        <svg width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
        <?php echo esc_html(elara_email()); ?>
      </a>
    </div>
    <div class="tb-right">
      <div class="tb-rating"><span class="tb-stars">★★★★★</span><span>4.9 / 5 · Trustpilot</span></div>
      <span>Mon–Sat · 9am–7pm</span>
    </div>
  </div>
</div>

<!-- NAVBAR -->
<header id="site-header">
  <nav class="nav-main">
    <div class="nav-inner">
      <a href="<?php echo esc_url(home_url('/')); ?>" class="nav-logo">
        <div class="logo-gem"><svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M12 2L8 8H2L6 13L4 20L12 16L20 20L18 13L22 8H16L12 2Z" fill="white"/></svg></div>
        <?php bloginfo('name'); ?>
      </a>

      <ul class="nav-items">
        <li class="nav-item">
          <span class="nav-link">About <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 12 15 18 9"/></svg></span>
          <div class="nav-dd">
            <span class="dd-label">Company</span>
            <a class="dd-link" href="<?php echo esc_url(elara_page_url('about-us')); ?>">About Elara Medical</a>
            <a class="dd-link" href="<?php echo esc_url(elara_page_url('about-us')); ?>">Our Surgeons</a>
            <a class="dd-link" href="<?php echo esc_url(elara_page_url('about-us')); ?>">Why Choose Us</a>
            <div class="drop-sep"></div>
            <span class="dd-label">Resources</span>
            <a class="dd-link" href="<?php echo esc_url(elara_page_url('patient-stories')); ?>">Patient Stories</a>
            <a class="dd-link" href="<?php echo esc_url(elara_page_url('patient-stories')); ?>">Reviews</a>
            <a class="dd-link" href="<?php echo esc_url(elara_page_url('blog')); ?>">Blog &amp; Guides</a>
          </div>
        </li>
        <li class="nav-item">
          <span class="nav-link">Hair <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 12 15 18 9"/></svg></span>
          <div class="nav-mega">
            <div>
              <div class="mega-col-hd">Procedures</div>
              <a class="mega-lnk" href="<?php echo esc_url(elara_page_url('hair-transplant')); ?>">FUE Hair Transplant</a>
              <a class="mega-lnk" href="<?php echo esc_url(elara_page_url('hair-transplant')); ?>">DHI Hair Transplant</a>
              <a class="mega-lnk" href="<?php echo esc_url(elara_page_url('hair-transplant')); ?>">Sapphire FUE</a>
              <a class="mega-lnk" href="<?php echo esc_url(elara_page_url('hair-transplant')); ?>">Beard Transplant</a>
              <a class="mega-lnk" href="<?php echo esc_url(elara_page_url('hair-transplant')); ?>">Female Hair Transplant</a>
            </div>
            <div>
              <div class="mega-col-hd">Information</div>
              <a class="mega-lnk" href="<?php echo esc_url(elara_page_url('hair-transplant')); ?>">Hair Transplant Cost</a>
              <a class="mega-lnk" href="<?php echo esc_url(elara_page_url('hair-transplant')); ?>">Am I a Candidate?</a>
              <a class="mega-lnk" href="<?php echo esc_url(elara_page_url('hair-transplant')); ?>">Recovery Guide</a>
              <div class="mega-col-hd" style="margin-top:12px">Gallery</div>
              <a class="mega-lnk" href="<?php echo esc_url(elara_page_url('patient-stories')); ?>">Before &amp; After Results</a>
            </div>
            <div class="mega-promo">
              <div><h4>Free Hair Assessment</h4><p>Find out how many grafts you need and which technique is best for you.</p></div>
              <a href="#" class="mega-promo-btn open-modal">Get Free Assessment</a>
            </div>
          </div>
        </li>
        <li class="nav-item">
          <span class="nav-link">Cosmetic <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 12 15 18 9"/></svg></span>
          <div class="nav-dd">
            <span class="dd-label">Face</span>
            <a class="dd-link" href="<?php echo esc_url(elara_page_url('cosmetic-surgery')); ?>">Rhinoplasty</a>
            <a class="dd-link" href="<?php echo esc_url(elara_page_url('cosmetic-surgery')); ?>">Facelift</a>
            <a class="dd-link" href="<?php echo esc_url(elara_page_url('cosmetic-surgery')); ?>">Eyelid Surgery</a>
            <a class="dd-link" href="<?php echo esc_url(elara_page_url('cosmetic-surgery')); ?>">Brow Lift</a>
            <div class="drop-sep"></div>
            <span class="dd-label">Breast &amp; Body</span>
            <a class="dd-link" href="<?php echo esc_url(elara_page_url('cosmetic-surgery')); ?>">Breast Augmentation</a>
            <a class="dd-link" href="<?php echo esc_url(elara_page_url('cosmetic-surgery')); ?>">Tummy Tuck</a>
            <a class="dd-link" href="<?php echo esc_url(elara_page_url('cosmetic-surgery')); ?>">Liposuction</a>
            <a class="dd-link" href="<?php echo esc_url(elara_page_url('mummy-makeover')); ?>">Mummy Makeover</a>
          </div>
        </li>
        <li class="nav-item">
          <span class="nav-link">Dental <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 12 15 18 9"/></svg></span>
          <div class="nav-dd">
            <span class="dd-label">Restorative</span>
            <a class="dd-link" href="<?php echo esc_url(elara_page_url('dental-treatments')); ?>">Dental Implants</a>
            <a class="dd-link" href="<?php echo esc_url(elara_page_url('dental-treatments')); ?>">Dental Crowns</a>
            <div class="drop-sep"></div>
            <span class="dd-label">Cosmetic</span>
            <a class="dd-link" href="<?php echo esc_url(elara_page_url('dental-treatments')); ?>">Hollywood Smile</a>
            <a class="dd-link" href="<?php echo esc_url(elara_page_url('dental-treatments')); ?>">Porcelain Veneers</a>
            <a class="dd-link" href="<?php echo esc_url(elara_page_url('dental-treatments')); ?>">Teeth Whitening</a>
          </div>
        </li>
        <li class="nav-item">
          <span class="nav-link">More <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 12 15 18 9"/></svg></span>
          <div class="nav-dd">
            <a class="dd-link" href="<?php echo esc_url(elara_page_url('weight-loss')); ?>">Weight Loss Surgery</a>
            <a class="dd-link" href="<?php echo esc_url(elara_page_url('eye-treatments')); ?>">Eye Treatments</a>
            <div class="drop-sep"></div>
            <a class="dd-link" href="<?php echo esc_url(elara_page_url('locations')); ?>">Our Locations</a>
            <a class="dd-link" href="<?php echo esc_url(elara_page_url('pricing')); ?>">Pricing &amp; Packages</a>
            <a class="dd-link" href="<?php echo esc_url(elara_page_url('patient-stories')); ?>">Patient Stories</a>
            <a class="dd-link" href="<?php echo esc_url(elara_page_url('blog')); ?>">Blog</a>
            <a class="dd-link" href="<?php echo esc_url(elara_page_url('faq')); ?>">FAQ</a>
          </div>
        </li>
        <li class="nav-item"><a class="nav-link" href="<?php echo esc_url(elara_page_url('cost-finance')); ?>">Cost &amp; Finance</a></li>
        <li class="nav-item"><a class="nav-link" href="<?php echo esc_url(elara_page_url('contact')); ?>">Contact</a></li>
      </ul>

      <a href="#" class="nav-cta open-modal">
        <svg width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
        Free Consultation
      </a>
      <div class="hbg" id="hbg"><span></span><span></span><span></span></div>
    </div>
  </nav>
</header>
</div><!-- /masthead -->

<!-- MOBILE DRAWER -->
<div class="mob-drawer" id="mobDrawer">
  <div class="mob-head">
    <a href="<?php echo esc_url(home_url('/')); ?>" class="mob-logo"><?php bloginfo('name'); ?></a>
    <div class="mob-x" id="mobX"><svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M18 6L6 18M6 6l12 12"/></svg></div>
  </div>
  <a class="mob-link" href="<?php echo esc_url(home_url('/')); ?>">Home</a>
  <a class="mob-link" href="<?php echo esc_url(elara_page_url('about-us')); ?>">About Us</a>
  <a class="mob-link" href="<?php echo esc_url(elara_page_url('hair-transplant')); ?>">Hair Transplant</a>
  <a class="mob-link" href="<?php echo esc_url(elara_page_url('cosmetic-surgery')); ?>">Cosmetic Surgery</a>
  <a class="mob-link" href="<?php echo esc_url(elara_page_url('mummy-makeover')); ?>">Mummy Makeover</a>
  <a class="mob-link" href="<?php echo esc_url(elara_page_url('dental-treatments')); ?>">Dental Treatments</a>
  <a class="mob-link" href="<?php echo esc_url(elara_page_url('weight-loss')); ?>">Weight Loss Surgery</a>
  <a class="mob-link" href="<?php echo esc_url(elara_page_url('eye-treatments')); ?>">Eye Treatments</a>
  <a class="mob-link" href="<?php echo esc_url(elara_page_url('locations')); ?>">Locations</a>
  <a class="mob-link" href="<?php echo esc_url(elara_page_url('patient-stories')); ?>">Patient Stories</a>
  <a class="mob-link" href="<?php echo esc_url(elara_page_url('pricing')); ?>">Pricing</a>
  <a class="mob-link" href="<?php echo esc_url(elara_page_url('blog')); ?>">Blog</a>
  <a class="mob-link" href="<?php echo esc_url(elara_page_url('faq')); ?>">FAQ</a>
  <a class="mob-link" href="<?php echo esc_url(elara_page_url('cost-finance')); ?>">Cost &amp; Finance</a>
  <a class="mob-link" href="<?php echo esc_url(elara_page_url('contact')); ?>">Contact</a>
  <div class="mob-ctas">
    <a href="#" class="btn btn-primary open-modal" style="text-align:center;display:block">Free Consultation</a>
    <a href="tel:<?php echo esc_attr(str_replace(' ','',elara_phone())); ?>" class="btn btn-outline" style="text-align:center;display:block">📞 <?php echo esc_html(elara_phone()); ?></a>
  </div>
</div>
<div class="mob-overlay" id="mobOverlay"></div>
