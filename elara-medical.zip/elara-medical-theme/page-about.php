<?php
/**
 * Template Name: About Us
 */
get_header();
?>
<div class="page-hero">
  <div class="container">
    <div>
      <div class="ph-breadcrumb"><a href="<?php echo home_url('/'); ?>">Home</a><span>›</span><span>About Us</span></div>
      <div class="ph-tags"><span class="badge badge-white">Our Story</span><span class="badge badge-white">Est. 2012</span></div>
      <h1 class="disp-xl ph-h1">We Are Elara Medical — <em style="font-style:italic">The Bridge Between You &amp; World-Class Care</em></h1>
      <p class="ph-sub">A UK-registered medical tourism facilitator with over a decade of experience connecting British patients with Istanbul's finest surgeons, dentists and clinics.</p>
      <div class="ph-ctas"><a href="#" class="btn btn-gold btn-lg open-modal">Book Free Consultation</a><a href="tel:<?php echo esc_attr(str_replace(' ','',elara_phone())); ?>" class="btn btn-outline-white btn-lg">📞 <?php echo esc_html(elara_phone()); ?></a></div>
    </div>
  </div>
</div>
<section class="sec">
  <div class="container">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:72px;align-items:center">
      <div data-aos="left">
        <span class="label label-teal" style="display:block;margin-bottom:12px">Our Story</span>
        <h2 class="disp-xl" style="margin-bottom:20px">Born From a <em style="font-style:italic">Simple Belief</em></h2>
        <p class="body-lg" style="margin-bottom:16px">In 2012, our founders — two former NHS patient liaison officers — identified a profound gap: Istanbul's medical talent was world-class, but British patients had no trustworthy, accountable way to access it safely.</p>
        <p class="body-lg" style="margin-bottom:28px">Over a decade later, we have facilitated more than 18,000 successful procedures, maintained a 98% patient satisfaction rating, and built a team of 40+ UK-based clinical advisors, patient coordinators and aftercare specialists.</p>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
          <div style="background:var(--off);border-radius:var(--radius-lg);padding:20px;border:1px solid var(--border);text-align:center"><div style="font-size:2.2rem;font-weight:800;color:var(--teal)">18,000+</div><div style="font-size:.8rem;color:var(--text3);font-weight:500;text-transform:uppercase;letter-spacing:.06em">Patients Helped</div></div>
          <div style="background:var(--off);border-radius:var(--radius-lg);padding:20px;border:1px solid var(--border);text-align:center"><div style="font-size:2.2rem;font-weight:800;color:var(--teal)">12+</div><div style="font-size:.8rem;color:var(--text3);font-weight:500;text-transform:uppercase;letter-spacing:.06em">Years Experience</div></div>
          <div style="background:var(--off);border-radius:var(--radius-lg);padding:20px;border:1px solid var(--border);text-align:center"><div style="font-size:2.2rem;font-weight:800;color:var(--teal)">40+</div><div style="font-size:.8rem;color:var(--text3);font-weight:500;text-transform:uppercase;letter-spacing:.06em">UK Team Members</div></div>
          <div style="background:var(--off);border-radius:var(--radius-lg);padding:20px;border:1px solid var(--border);text-align:center"><div style="font-size:2.2rem;font-weight:800;color:var(--teal)">98%</div><div style="font-size:.8rem;color:var(--text3);font-weight:500;text-transform:uppercase;letter-spacing:.06em">Satisfaction Rate</div></div>
        </div>
      </div>
      <div data-aos="right" style="border-radius:var(--radius-2xl);overflow:hidden;height:520px">
        <img src="https://images.unsplash.com/photo-1551190822-a9333d879b1f?w=700&q=80" alt="Elara Medical team" loading="lazy" style="width:100%;height:100%;object-fit:cover">
      </div>
    </div>
  </div>
</section>
<section class="sec bg-off">
  <div class="container">
    <div class="sh center" data-aos="up" style="margin-bottom:52px">
      <span class="label label-teal">Our Surgeons</span>
      <h2 class="disp-xl">Meet the Specialists Behind <em style="font-style:italic">Your Results</em></h2>
    </div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:24px">
      <div class="card" data-aos="up" style="padding:0"><div style="height:260px;overflow:hidden"><img src="https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=500&q=80" alt="Dr. Ahmet Yilmaz" loading="lazy" style="width:100%;height:100%;object-fit:cover"></div><div style="padding:24px"><div style="font-size:.72rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--teal);margin-bottom:6px">Hair Restoration</div><h3 style="font-family:var(--font-display);font-size:1.35rem;font-weight:600;color:var(--dark);margin-bottom:5px">Dr. Ahmet Yilmaz</h3><p style="font-size:.83rem;color:var(--text2);line-height:1.6;margin-bottom:14px">22 years · 9,000+ procedures · Turkish Society of Plastic Surgeons board certified · Published researcher.</p><div style="display:flex;align-items:center;gap:8px"><span style="color:#F59E0B;font-size:.9rem">★★★★★</span><span style="font-size:.78rem;color:var(--text3)">4.9/5 patient rating</span></div></div></div>
      <div class="card" data-aos="up" style="padding:0"><div style="height:260px;overflow:hidden"><img src="https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=500&q=80" alt="Dr. Selin Kaya" loading="lazy" style="width:100%;height:100%;object-fit:cover"></div><div style="padding:24px"><div style="font-size:.72rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--teal);margin-bottom:6px">Facial &amp; Rhinoplasty</div><h3 style="font-family:var(--font-display);font-size:1.35rem;font-weight:600;color:var(--dark);margin-bottom:5px">Dr. Selin Kaya</h3><p style="font-size:.83rem;color:var(--text2);line-height:1.6;margin-bottom:14px">16 years specialising in rhinoplasty · ISAPS member · 800+ rhinoplasties per year · International Speaker.</p><div style="display:flex;align-items:center;gap:8px"><span style="color:#F59E0B;font-size:.9rem">★★★★★</span><span style="font-size:.78rem;color:var(--text3)">4.8/5 patient rating</span></div></div></div>
      <div class="card" data-aos="up" style="padding:0"><div style="height:260px;overflow:hidden"><img src="https://images.unsplash.com/photo-1582750433449-648ed127bb54?w=500&q=80" alt="Dr. Mehmet Demir" loading="lazy" style="width:100%;height:100%;object-fit:cover"></div><div style="padding:24px"><div style="font-size:.72rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--teal);margin-bottom:6px">Plastic &amp; Body Surgery</div><h3 style="font-family:var(--font-display);font-size:1.35rem;font-weight:600;color:var(--dark);margin-bottom:5px">Dr. Mehmet Demir</h3><p style="font-size:.83rem;color:var(--text2);line-height:1.6;margin-bottom:14px">19 years in body contouring · EBOPRAS member · Specialist in mummy makeover procedures.</p><div style="display:flex;align-items:center;gap:8px"><span style="color:#F59E0B;font-size:.9rem">★★★★★</span><span style="font-size:.78rem;color:var(--text3)">4.9/5 patient rating</span></div></div></div>
    </div>
  </div>
</section>
<section class="sec"><div class="container"><div class="sh center" data-aos="up" style="margin-bottom:44px"><span class="label label-teal">Certifications</span><h2 class="disp-xl">Accreditations &amp; <em style="font-style:italic">Standards</em></h2></div><div class="accred-grid" data-aos="up"><div class="accred-card"><div class="accred-icon">🏆</div><div class="accred-name">ISO 9001:2015</div><div class="accred-desc">International quality management certification</div></div><div class="accred-card"><div class="accred-icon">🌐</div><div class="accred-name">JCI Accreditation</div><div class="accred-desc">Joint Commission International hospital partners</div></div><div class="accred-card"><div class="accred-icon">⭐</div><div class="accred-name">Trustpilot Excellent</div><div class="accred-desc">4.9/5 from 3,200+ verified reviews</div></div><div class="accred-card"><div class="accred-icon">🔐</div><div class="accred-name">ICO Registered</div><div class="accred-desc">Full GDPR compliance</div></div><div class="accred-card"><div class="accred-icon">🏢</div><div class="accred-name">UK Companies House</div><div class="accred-desc">Registered England &amp; Wales</div></div></div></div></section>
<section class="cta-banner"><div class="container"><h2 class="disp-xl" style="color:#fff" data-aos="up">Start Your Journey With <em style="font-style:italic">Elara Medical</em></h2><p data-aos="up">18,000+ patients have trusted us. Your free consultation is waiting.</p><div class="cta-btns" data-aos="up"><a href="#" class="btn btn-gold btn-xl open-modal">Book Free Consultation</a><a href="<?php echo esc_url(elara_page_url('contact')); ?>" class="btn btn-outline-white btn-xl">Contact Our Team</a></div></div></section>
<?php get_footer();
