<?php
/**
 * Template Name: Cost & Finance
 * @package elara-medical
 */
get_header();
$phone = elara_phone();
$phone_clean = str_replace(' ', '', $phone);
?>

<!-- HERO -->
<div class="page-hero">
  <div class="container">
    <div>
      <div class="ph-breadcrumb"><a href="<?php echo esc_url(home_url('/')); ?>">Home</a><span>›</span><span>Cost &amp; Finance</span></div>
      <div class="ph-tags"><span class="badge badge-white">Transparent Pricing</span><span class="badge badge-white">0% Finance Available</span><span class="badge badge-white">No Hidden Fees</span></div>
      <h1 class="disp-xl ph-h1">Cost &amp; Finance — <em style="font-style:italic">Clear Pricing. Flexible Payments. No Surprises.</em></h1>
      <p class="ph-sub">Cosmetic procedures are not available on the NHS. At Elara Medical, we believe world-class treatment should be financially accessible — every price we quote is fully all-inclusive, with flexible 0% finance options available to spread the cost.</p>
      <div class="ph-ctas">
        <a href="#price-calc" class="btn btn-gold btn-lg">💷 Get My Price Estimate</a>
        <a href="#finance-opts" class="btn btn-outline-white btn-lg">📋 View Finance Options</a>
      </div>
    </div>
    <div class="ph-right">
      <h4>Our Pricing Promise</h4>
      <div class="quick-list">
        <div class="ql-item"><span class="ql-icon">✓</span>100% transparent — no hidden fees</div>
        <div class="ql-item"><span class="ql-icon">✓</span>All-inclusive packages only</div>
        <div class="ql-item"><span class="ql-icon">✓</span>0% interest finance available</div>
        <div class="ql-item"><span class="ql-icon">✓</span>Price-match guarantee</div>
        <div class="ql-item"><span class="ql-icon">✓</span>Low deposit to secure your date</div>
        <div class="ql-item"><span class="ql-icon">✓</span>Balance payable before departure</div>
      </div>
    </div>
  </div>
</div>

<!-- WHY SO AFFORDABLE -->
<section class="sec bg-off">
  <div class="container">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:72px;align-items:center">
      <div data-aos="left">
        <span class="label label-teal" style="display:block;margin-bottom:12px">Why Istanbul?</span>
        <h2 class="disp-xl" style="margin-bottom:18px">Premium Quality at <em style="font-style:italic">Accessible Prices</em></h2>
        <p class="body-lg" style="margin-bottom:16px">The significant cost difference between Istanbul and the UK is not a reflection of quality — it is a reflection of economics. Operating costs, staff wages and overhead expenses in Turkey are substantially lower than in the UK, allowing our partner clinics to charge less while maintaining identical standards.</p>
        <p class="body-lg" style="margin-bottom:28px">Our partner hospitals use the same implants, instruments and technology as London's leading private clinics. Your surgeon holds equivalent international board certifications. The only difference is the price you pay.</p>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
          <div style="background:#fff;border-radius:var(--radius-xl);padding:20px;border:1px solid var(--border);text-align:center"><div style="font-size:2.5rem;font-weight:800;color:var(--teal);line-height:1">50–75%</div><div style="font-size:.8rem;color:var(--text3);font-weight:500;text-transform:uppercase;letter-spacing:.06em;margin-top:4px">Average saving vs UK</div></div>
          <div style="background:#fff;border-radius:var(--radius-xl);padding:20px;border:1px solid var(--border);text-align:center"><div style="font-size:2.5rem;font-weight:800;color:var(--teal);line-height:1">£0</div><div style="font-size:.8rem;color:var(--text3);font-weight:500;text-transform:uppercase;letter-spacing:.06em;margin-top:4px">Hidden fees. Always.</div></div>
          <div style="background:#fff;border-radius:var(--radius-xl);padding:20px;border:1px solid var(--border);text-align:center"><div style="font-size:2.5rem;font-weight:800;color:var(--teal);line-height:1">18,000+</div><div style="font-size:.8rem;color:var(--text3);font-weight:500;text-transform:uppercase;letter-spacing:.06em;margin-top:4px">Patients saved money</div></div>
          <div style="background:#fff;border-radius:var(--radius-xl);padding:20px;border:1px solid var(--border);text-align:center"><div style="font-size:2.5rem;font-weight:800;color:var(--teal);line-height:1">£4,200</div><div style="font-size:.8rem;color:var(--text3);font-weight:500;text-transform:uppercase;letter-spacing:.06em;margin-top:4px">Average patient saving</div></div>
        </div>
      </div>
      <div data-aos="right">
        <div style="background:var(--dark2);border-radius:var(--radius-2xl);padding:32px">
          <h3 style="font-family:var(--font-display);font-size:1.4rem;color:#fff;margin-bottom:20px">What Every Package Includes</h3>
          <div style="display:flex;flex-direction:column;gap:10px">
            <?php
            $items = [
              ['✈','Flight booking assistance','Recommended routes from all UK airports'],
              ['🏨','4 or 5-star hotel accommodation','For the full duration of your stay'],
              ['🚗','VIP airport & clinic transfers','All journeys handled, door to door'],
              ['🏥','Pre-operative medical tests','Blood tests, ECG, health screening'],
              ['💊','All post-op medications','Everything prescribed for your recovery'],
              ['📞','Dedicated UK patient coordinator','Available throughout your entire journey'],
              ['🔄','12-month aftercare support','Follow-up calls at key recovery milestones'],
            ];
            foreach($items as $item): ?>
            <div style="display:flex;align-items:center;gap:10px;padding:10px 12px;background:rgba(255,255,255,.06);border-radius:var(--radius-md)">
              <span style="font-size:1.1rem"><?php echo $item[0]; ?></span>
              <div><div style="font-size:.84rem;font-weight:600;color:#fff"><?php echo $item[1]; ?></div><div style="font-size:.74rem;color:rgba(255,255,255,.45)"><?php echo $item[2]; ?></div></div>
            </div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- PRICE CALCULATOR -->
<section class="sec" id="price-calc">
  <div class="container">
    <div class="sh center" data-aos="up" style="margin-bottom:52px">
      <span class="label label-teal">Price Estimator</span>
      <h2 class="disp-xl">Get Your Personalised <em style="font-style:italic">Price Estimate</em></h2>
      <p>Select your treatment and package for an instant estimate. Your final price is confirmed during your free consultation.</p>
    </div>
    <div style="background:#fff;border-radius:var(--radius-2xl);box-shadow:var(--shadow-xl);border:1px solid var(--border);overflow:hidden;max-width:900px;margin:0 auto" data-aos="up">
      <div style="background:var(--grad);padding:28px 36px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:16px">
        <div><h3 style="font-family:var(--font-display);font-size:1.5rem;color:#fff;margin-bottom:4px">Elara Medical Price Calculator</h3><p style="font-size:.82rem;color:rgba(255,255,255,.6)">Instant estimates · All-inclusive · No obligation</p></div>
        <div style="display:flex;align-items:center;gap:8px;background:rgba(255,255,255,.1);padding:8px 16px;border-radius:var(--radius-pill)"><span style="color:#F59E0B;font-size:.9rem">★★★★★</span><span style="color:#fff;font-size:.82rem;font-weight:500">4.9/5 Trustpilot</span></div>
      </div>
      <div style="display:flex;border-bottom:1px solid var(--border)">
        <div class="wpcalc-step active" data-s="1" style="flex:1;padding:14px 20px;text-align:center;font-size:.82rem;font-weight:600;color:var(--teal);border-bottom:3px solid var(--teal);cursor:pointer">1. Treatment</div>
        <div class="wpcalc-step" data-s="2" style="flex:1;padding:14px 20px;text-align:center;font-size:.82rem;font-weight:600;color:var(--text3);border-bottom:3px solid transparent;cursor:pointer">2. Procedure</div>
        <div class="wpcalc-step" data-s="3" style="flex:1;padding:14px 20px;text-align:center;font-size:.82rem;font-weight:600;color:var(--text3);border-bottom:3px solid transparent;cursor:pointer">3. Package</div>
        <div class="wpcalc-step" data-s="4" style="flex:1;padding:14px 20px;text-align:center;font-size:.82rem;font-weight:600;color:var(--text3);border-bottom:3px solid transparent;cursor:pointer">4. Your Estimate</div>
      </div>
      <div style="padding:36px">
        <!-- Step 1 -->
        <div id="wcp-1" class="wcp">
          <h4 style="font-family:var(--font-display);font-size:1.2rem;color:var(--dark);margin-bottom:20px">Which type of treatment are you interested in?</h4>
          <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px">
            <div class="wco" onclick="wpCat('hair',this)" style="padding:20px 16px;border:2px solid var(--border);border-radius:var(--radius-xl);text-align:center;cursor:pointer;transition:all .2s"><div style="font-size:2rem;margin-bottom:8px">💇</div><div style="font-weight:700;color:var(--dark);font-size:.88rem">Hair Transplant</div><div style="font-size:.74rem;color:var(--text3);margin-top:3px">From £1,499</div></div>
            <div class="wco" onclick="wpCat('cosmetic',this)" style="padding:20px 16px;border:2px solid var(--border);border-radius:var(--radius-xl);text-align:center;cursor:pointer;transition:all .2s"><div style="font-size:2rem;margin-bottom:8px">💉</div><div style="font-weight:700;color:var(--dark);font-size:.88rem">Cosmetic Surgery</div><div style="font-size:.74rem;color:var(--text3);margin-top:3px">From £1,800</div></div>
            <div class="wco" onclick="wpCat('dental',this)" style="padding:20px 16px;border:2px solid var(--border);border-radius:var(--radius-xl);text-align:center;cursor:pointer;transition:all .2s"><div style="font-size:2rem;margin-bottom:8px">🦷</div><div style="font-weight:700;color:var(--dark);font-size:.88rem">Dental Treatments</div><div style="font-size:.74rem;color:var(--text3);margin-top:3px">From £149</div></div>
            <div class="wco" onclick="wpCat('weight',this)" style="padding:20px 16px;border:2px solid var(--border);border-radius:var(--radius-xl);text-align:center;cursor:pointer;transition:all .2s"><div style="font-size:2rem;margin-bottom:8px">⚖️</div><div style="font-weight:700;color:var(--dark);font-size:.88rem">Weight Loss Surgery</div><div style="font-size:.74rem;color:var(--text3);margin-top:3px">From £1,400</div></div>
            <div class="wco" onclick="wpCat('eye',this)" style="padding:20px 16px;border:2px solid var(--border);border-radius:var(--radius-xl);text-align:center;cursor:pointer;transition:all .2s"><div style="font-size:2rem;margin-bottom:8px">👁</div><div style="font-weight:700;color:var(--dark);font-size:.88rem">Eye Treatments</div><div style="font-size:.74rem;color:var(--text3);margin-top:3px">From £399/eye</div></div>
            <div class="wco" onclick="wpCat('mummy',this)" style="padding:20px 16px;border:2px solid var(--border);border-radius:var(--radius-xl);text-align:center;cursor:pointer;transition:all .2s"><div style="font-size:2rem;margin-bottom:8px">⭐</div><div style="font-weight:700;color:var(--dark);font-size:.88rem">Mummy Makeover</div><div style="font-size:.74rem;color:var(--text3);margin-top:3px">From £5,200</div></div>
          </div>
        </div>
        <!-- Step 2 -->
        <div id="wcp-2" class="wcp" style="display:none">
          <h4 style="font-family:var(--font-display);font-size:1.2rem;color:var(--dark);margin-bottom:20px">Which procedure are you considering?</h4>
          <div id="wpProcList" style="display:flex;flex-direction:column;gap:8px"></div>
          <button onclick="wpBack(1)" style="margin-top:20px;padding:10px 20px;border:1.5px solid var(--border);border-radius:var(--radius-pill);font-size:.84rem;font-weight:600;color:var(--text2);background:#fff;cursor:pointer;font-family:inherit">← Back</button>
        </div>
        <!-- Step 3 -->
        <div id="wcp-3" class="wcp" style="display:none">
          <h4 style="font-family:var(--font-display);font-size:1.2rem;color:var(--dark);margin-bottom:20px">Which package would you like?</h4>
          <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px">
            <div class="wco" onclick="wpPkg('essential',this)" style="padding:20px 16px;border:2px solid var(--border);border-radius:var(--radius-xl);text-align:center;cursor:pointer;transition:all .2s"><div style="font-size:1.8rem;margin-bottom:8px">✈</div><div style="font-weight:700;color:var(--dark);font-size:.88rem">Essential</div><div style="font-size:.74rem;color:var(--text3);margin-top:3px">Base all-inclusive</div></div>
            <div class="wco" onclick="wpPkg('premium',this)" style="padding:20px 16px;border:2px solid var(--teal);border-radius:var(--radius-xl);text-align:center;cursor:pointer;transition:all .2s;background:var(--teal-l)"><div style="font-size:1.8rem;margin-bottom:8px">⭐</div><div style="font-weight:700;color:var(--teal-d);font-size:.88rem">Premium</div><div style="font-size:.74rem;color:var(--teal);margin-top:3px;font-weight:600">Most Popular</div></div>
            <div class="wco" onclick="wpPkg('elite',this)" style="padding:20px 16px;border:2px solid var(--border);border-radius:var(--radius-xl);text-align:center;cursor:pointer;transition:all .2s"><div style="font-size:1.8rem;margin-bottom:8px">💎</div><div style="font-weight:700;color:var(--dark);font-size:.88rem">Elite</div><div style="font-size:.74rem;color:var(--text3);margin-top:3px">Ultimate experience</div></div>
          </div>
          <button onclick="wpBack(2)" style="margin-top:20px;padding:10px 20px;border:1.5px solid var(--border);border-radius:var(--radius-pill);font-size:.84rem;font-weight:600;color:var(--text2);background:#fff;cursor:pointer;font-family:inherit">← Back</button>
        </div>
        <!-- Step 4 -->
        <div id="wcp-4" class="wcp" style="display:none">
          <div style="text-align:center;margin-bottom:24px"><div style="font-size:.75rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--teal);margin-bottom:8px">Your Personalised Estimate</div><div style="font-family:var(--font-display);font-size:.95rem;color:var(--text2)" id="wp-title"></div></div>
          <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:16px;margin-bottom:24px">
            <div style="background:var(--teal-l);border-radius:var(--radius-xl);padding:22px;text-align:center;border:1px solid rgba(11,107,150,.18)"><div style="font-size:.72rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--teal);margin-bottom:6px">Elara Medical</div><div style="font-size:2.4rem;font-weight:800;color:var(--teal);line-height:1" id="wp-price">£0</div><div style="font-size:.74rem;color:var(--teal-d);margin-top:4px">All-inclusive</div></div>
            <div style="background:var(--off);border-radius:var(--radius-xl);padding:22px;text-align:center;border:1px solid var(--border)"><div style="font-size:.72rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--text3);margin-bottom:6px">UK Average</div><div style="font-size:2.4rem;font-weight:800;color:var(--text2);line-height:1;text-decoration:line-through;opacity:.6" id="wp-uk">£0</div><div style="font-size:.74rem;color:var(--text3);margin-top:4px">Procedure only</div></div>
            <div style="background:var(--gold-l);border-radius:var(--radius-xl);padding:22px;text-align:center;border:1px solid rgba(200,152,42,.2)"><div style="font-size:.72rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--gold-d);margin-bottom:6px">You Save</div><div style="font-size:2.4rem;font-weight:800;color:var(--gold-d);line-height:1" id="wp-save">£0</div><div style="font-size:.74rem;color:var(--gold-d);margin-top:4px" id="wp-pct">vs UK</div></div>
          </div>
          <div style="background:var(--dark2);border-radius:var(--radius-xl);padding:18px 22px;margin-bottom:20px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px">
            <div><div style="font-size:.72rem;font-weight:700;text-transform:uppercase;color:rgba(255,255,255,.5);letter-spacing:.08em;margin-bottom:3px">Or spread the cost with 0% finance</div><div style="color:#fff;font-size:.88rem">Pay as little as <strong id="wp-monthly" style="color:var(--gold)">£0/month</strong> over 12 months</div></div>
            <a href="#finance-opts" class="btn btn-gold" style="font-size:.82rem;padding:10px 18px">View Finance Options</a>
          </div>
          <div style="background:var(--teal-l);border-radius:var(--radius-lg);padding:13px 15px;font-size:.76rem;color:var(--text2);line-height:1.6;margin-bottom:20px;border-left:4px solid var(--teal)"><strong style="color:var(--teal-d)">Disclaimer:</strong> This is a budgeting estimate only. Your final price is confirmed following a free consultation and may vary based on the complexity of your individual case.</div>
          <div style="display:flex;gap:12px;flex-wrap:wrap">
            <a href="#" class="btn btn-primary open-modal" style="flex:1;justify-content:center">🗓 Book Free Consultation</a>
            <button onclick="wpReset()" class="btn btn-outline" style="padding:13px 24px">Start Again</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- FULL PRICING TABLE -->
<section class="sec bg-off">
  <div class="container">
    <div class="sh center" data-aos="up" style="margin-bottom:44px">
      <span class="label label-teal">Full Price Guide</span>
      <h2 class="disp-xl">All Procedures — <em style="font-style:italic">Istanbul vs UK</em></h2>
      <p>Every price below is fully all-inclusive. UK prices are procedure-only market averages.</p>
    </div>
    <div style="display:flex;gap:8px;margin-bottom:28px;flex-wrap:wrap;justify-content:center" data-aos="up">
      <button class="fbtn on" onclick="wpFilterPricing(this,'all')">All Procedures</button>
      <button class="fbtn" onclick="wpFilterPricing(this,'hair')">Hair Transplant</button>
      <button class="fbtn" onclick="wpFilterPricing(this,'cosmetic')">Cosmetic Surgery</button>
      <button class="fbtn" onclick="wpFilterPricing(this,'dental')">Dental</button>
      <button class="fbtn" onclick="wpFilterPricing(this,'weight')">Weight Loss</button>
      <button class="fbtn" onclick="wpFilterPricing(this,'eye')">Eye Treatments</button>
    </div>
    <div style="overflow:hidden;border-radius:var(--radius-xl);box-shadow:var(--shadow-lg)" data-aos="up">
      <table id="wpPricingTable" style="width:100%;border-collapse:collapse">
        <thead><tr style="background:var(--dark2)"><th style="padding:16px 20px;text-align:left;color:#fff;font-size:.8rem;font-weight:700;letter-spacing:.04em;width:35%">Procedure</th><th style="padding:16px 20px;text-align:left;color:rgba(255,255,255,.6);font-size:.8rem;font-weight:600;width:22%">UK Average</th><th style="padding:16px 20px;text-align:left;background:var(--teal);color:#fff;font-size:.8rem;font-weight:700;width:22%">Elara Medical</th><th style="padding:16px 20px;text-align:left;color:rgba(255,255,255,.6);font-size:.8rem;font-weight:600;width:21%">You Save</th></tr></thead>
        <tbody id="wpPricingBody">
          <tr data-wpc="hair"><td colspan="4" style="background:var(--teal-l);padding:10px 20px;font-size:.72rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--teal)">💇 Hair Transplant</td></tr>
          <tr data-wpc="hair" style="border-bottom:1px solid var(--border)"><td style="padding:14px 20px;font-weight:600;color:var(--dark);font-size:.88rem;background:var(--off)">FUE Hair Transplant</td><td style="padding:14px 20px;font-size:.88rem;color:var(--text2)">£7,000–£12,000</td><td style="padding:14px 20px;font-weight:700;color:var(--teal);font-size:.92rem;background:rgba(11,107,150,.04)">From £1,499</td><td style="padding:14px 20px;font-size:.88rem;color:var(--text2)"><strong>Up to £10,500</strong></td></tr>
          <tr data-wpc="hair" style="border-bottom:1px solid var(--border)"><td style="padding:14px 20px;font-weight:600;color:var(--dark);font-size:.88rem;background:var(--off)">DHI Hair Transplant</td><td style="padding:14px 20px;font-size:.88rem;color:var(--text2)">£9,000–£15,000</td><td style="padding:14px 20px;font-weight:700;color:var(--teal);font-size:.92rem;background:rgba(11,107,150,.04)">From £1,899</td><td style="padding:14px 20px;font-size:.88rem;color:var(--text2)"><strong>Up to £13,100</strong></td></tr>
          <tr data-wpc="hair" style="border-bottom:1px solid var(--border)"><td style="padding:14px 20px;font-weight:600;color:var(--dark);font-size:.88rem;background:var(--off)">Sapphire FUE</td><td style="padding:14px 20px;font-size:.88rem;color:var(--text2)">£8,000–£13,000</td><td style="padding:14px 20px;font-weight:700;color:var(--teal);font-size:.92rem;background:rgba(11,107,150,.04)">From £1,699</td><td style="padding:14px 20px;font-size:.88rem;color:var(--text2)"><strong>Up to £11,300</strong></td></tr>
          <tr data-wpc="hair" style="border-bottom:1px solid var(--border)"><td style="padding:14px 20px;font-weight:600;color:var(--dark);font-size:.88rem;background:var(--off)">Beard Transplant</td><td style="padding:14px 20px;font-size:.88rem;color:var(--text2)">£4,000–£7,000</td><td style="padding:14px 20px;font-weight:700;color:var(--teal);font-size:.92rem;background:rgba(11,107,150,.04)">From £1,299</td><td style="padding:14px 20px;font-size:.88rem;color:var(--text2)"><strong>Up to £5,700</strong></td></tr>
          <tr data-wpc="cosmetic"><td colspan="4" style="background:var(--teal-l);padding:10px 20px;font-size:.72rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--teal)">💉 Cosmetic Surgery</td></tr>
          <tr data-wpc="cosmetic" style="border-bottom:1px solid var(--border)"><td style="padding:14px 20px;font-weight:600;color:var(--dark);font-size:.88rem;background:var(--off)">Rhinoplasty (Nose Job)</td><td style="padding:14px 20px;font-size:.88rem;color:var(--text2)">£5,500–£9,000</td><td style="padding:14px 20px;font-weight:700;color:var(--teal);font-size:.92rem;background:rgba(11,107,150,.04)">From £2,200</td><td style="padding:14px 20px;font-size:.88rem;color:var(--text2)"><strong>Up to £6,800</strong></td></tr>
          <tr data-wpc="cosmetic" style="border-bottom:1px solid var(--border)"><td style="padding:14px 20px;font-weight:600;color:var(--dark);font-size:.88rem;background:var(--off)">Breast Augmentation</td><td style="padding:14px 20px;font-size:.88rem;color:var(--text2)">£5,000–£8,000</td><td style="padding:14px 20px;font-weight:700;color:var(--teal);font-size:.92rem;background:rgba(11,107,150,.04)">From £2,800</td><td style="padding:14px 20px;font-size:.88rem;color:var(--text2)"><strong>Up to £5,200</strong></td></tr>
          <tr data-wpc="cosmetic" style="border-bottom:1px solid var(--border)"><td style="padding:14px 20px;font-weight:600;color:var(--dark);font-size:.88rem;background:var(--off)">Tummy Tuck</td><td style="padding:14px 20px;font-size:.88rem;color:var(--text2)">£6,000–£10,000</td><td style="padding:14px 20px;font-weight:700;color:var(--teal);font-size:.92rem;background:rgba(11,107,150,.04)">From £3,200</td><td style="padding:14px 20px;font-size:.88rem;color:var(--text2)"><strong>Up to £6,800</strong></td></tr>
          <tr data-wpc="cosmetic" style="border-bottom:1px solid var(--border)"><td style="padding:14px 20px;font-weight:600;color:var(--dark);font-size:.88rem;background:var(--off)">Mummy Makeover</td><td style="padding:14px 20px;font-size:.88rem;color:var(--text2)">£14,000–£26,000</td><td style="padding:14px 20px;font-weight:700;color:var(--teal);font-size:.92rem;background:rgba(11,107,150,.04)">From £5,200</td><td style="padding:14px 20px;font-size:.88rem;color:var(--text2)"><strong>Up to £20,800</strong></td></tr>
          <tr data-wpc="dental"><td colspan="4" style="background:var(--teal-l);padding:10px 20px;font-size:.72rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--teal)">🦷 Dental Treatments</td></tr>
          <tr data-wpc="dental" style="border-bottom:1px solid var(--border)"><td style="padding:14px 20px;font-weight:600;color:var(--dark);font-size:.88rem;background:var(--off)">Dental Implant (single)</td><td style="padding:14px 20px;font-size:.88rem;color:var(--text2)">£2,000–£3,500</td><td style="padding:14px 20px;font-weight:700;color:var(--teal);font-size:.92rem;background:rgba(11,107,150,.04)">From £499</td><td style="padding:14px 20px;font-size:.88rem;color:var(--text2)"><strong>Up to £3,000</strong></td></tr>
          <tr data-wpc="dental" style="border-bottom:1px solid var(--border)"><td style="padding:14px 20px;font-weight:600;color:var(--dark);font-size:.88rem;background:var(--off)">Hollywood Smile (full)</td><td style="padding:14px 20px;font-size:.88rem;color:var(--text2)">£15,000–£25,000</td><td style="padding:14px 20px;font-weight:700;color:var(--teal);font-size:.92rem;background:rgba(11,107,150,.04)">From £2,800</td><td style="padding:14px 20px;font-size:.88rem;color:var(--text2)"><strong>Up to £22,200</strong></td></tr>
          <tr data-wpc="dental" style="border-bottom:1px solid var(--border)"><td style="padding:14px 20px;font-weight:600;color:var(--dark);font-size:.88rem;background:var(--off)">Porcelain Veneers (per tooth)</td><td style="padding:14px 20px;font-size:.88rem;color:var(--text2)">£800–£1,500</td><td style="padding:14px 20px;font-weight:700;color:var(--teal);font-size:.92rem;background:rgba(11,107,150,.04)">From £199</td><td style="padding:14px 20px;font-size:.88rem;color:var(--text2)"><strong>Up to £1,300</strong></td></tr>
          <tr data-wpc="weight"><td colspan="4" style="background:var(--teal-l);padding:10px 20px;font-size:.72rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--teal)">⚖️ Weight Loss Surgery</td></tr>
          <tr data-wpc="weight" style="border-bottom:1px solid var(--border)"><td style="padding:14px 20px;font-weight:600;color:var(--dark);font-size:.88rem;background:var(--off)">Gastric Sleeve</td><td style="padding:14px 20px;font-size:.88rem;color:var(--text2)">£8,000–£12,000</td><td style="padding:14px 20px;font-weight:700;color:var(--teal);font-size:.92rem;background:rgba(11,107,150,.04)">From £2,800</td><td style="padding:14px 20px;font-size:.88rem;color:var(--text2)"><strong>Up to £9,200</strong></td></tr>
          <tr data-wpc="weight" style="border-bottom:1px solid var(--border)"><td style="padding:14px 20px;font-weight:600;color:var(--dark);font-size:.88rem;background:var(--off)">Gastric Bypass</td><td style="padding:14px 20px;font-size:.88rem;color:var(--text2)">£10,000–£15,000</td><td style="padding:14px 20px;font-weight:700;color:var(--teal);font-size:.92rem;background:rgba(11,107,150,.04)">From £3,400</td><td style="padding:14px 20px;font-size:.88rem;color:var(--text2)"><strong>Up to £11,600</strong></td></tr>
          <tr data-wpc="weight" style="border-bottom:1px solid var(--border)"><td style="padding:14px 20px;font-weight:600;color:var(--dark);font-size:.88rem;background:var(--off)">Gastric Balloon</td><td style="padding:14px 20px;font-size:.88rem;color:var(--text2)">£3,000–£5,000</td><td style="padding:14px 20px;font-weight:700;color:var(--teal);font-size:.92rem;background:rgba(11,107,150,.04)">From £1,400</td><td style="padding:14px 20px;font-size:.88rem;color:var(--text2)"><strong>Up to £3,600</strong></td></tr>
          <tr data-wpc="eye"><td colspan="4" style="background:var(--teal-l);padding:10px 20px;font-size:.72rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--teal)">👁 Eye Treatments</td></tr>
          <tr data-wpc="eye" style="border-bottom:1px solid var(--border)"><td style="padding:14px 20px;font-weight:600;color:var(--dark);font-size:.88rem;background:var(--off)">LASIK (per eye)</td><td style="padding:14px 20px;font-size:.88rem;color:var(--text2)">£1,500–£2,500</td><td style="padding:14px 20px;font-weight:700;color:var(--teal);font-size:.92rem;background:rgba(11,107,150,.04)">From £399</td><td style="padding:14px 20px;font-size:.88rem;color:var(--text2)"><strong>Up to £2,100</strong></td></tr>
          <tr data-wpc="eye" style="border-bottom:1px solid var(--border)"><td style="padding:14px 20px;font-weight:600;color:var(--dark);font-size:.88rem;background:var(--off)">SMILE (per eye)</td><td style="padding:14px 20px;font-size:.88rem;color:var(--text2)">£1,800–£3,000</td><td style="padding:14px 20px;font-weight:700;color:var(--teal);font-size:.92rem;background:rgba(11,107,150,.04)">From £599</td><td style="padding:14px 20px;font-size:.88rem;color:var(--text2)"><strong>Up to £2,400</strong></td></tr>
        </tbody>
      </table>
    </div>
    <p style="font-size:.76rem;color:var(--text3);margin-top:12px;text-align:center">All Elara Medical prices are fully all-inclusive. UK averages are market comparisons for procedure only. Prices correct as of 2025.</p>
  </div>
</section>

<!-- FINANCE OPTIONS -->
<section class="sec" id="finance-opts">
  <div class="container">
    <div class="sh center" data-aos="up" style="margin-bottom:52px">
      <span class="label label-teal">Flexible Finance</span>
      <h2 class="disp-xl">Spread the Cost With <em style="font-style:italic">0% Finance</em></h2>
      <p>We believe financial barriers should never stand between you and the treatment you deserve.</p>
    </div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:24px;margin-bottom:48px">
      <div class="card" data-aos="up" style="padding:32px;text-align:center"><div style="width:64px;height:64px;background:var(--teal-l);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 18px;font-size:1.8rem">💳</div><h3 style="font-family:var(--font-display);font-size:1.3rem;font-weight:700;color:var(--dark);margin-bottom:10px">Pay in Full</h3><p style="font-size:.84rem;color:var(--text2);line-height:1.65;margin-bottom:16px">Pay the full amount before departure. A small deposit secures your surgery date and surgeon assignment.</p><div style="background:var(--teal-l);border-radius:var(--radius-lg);padding:10px 14px;font-size:.82rem;color:var(--teal-d);font-weight:600">Deposit from £200 · Balance before departure</div></div>
      <div class="card" data-aos="up" style="padding:32px;text-align:center;border:2px solid var(--teal);position:relative"><div style="position:absolute;top:-1px;right:16px;background:var(--grad-gold);color:var(--dark);font-size:.68rem;font-weight:800;letter-spacing:.08em;text-transform:uppercase;padding:5px 12px;border-radius:0 0 var(--radius-md) var(--radius-md)">Most Popular</div><div style="width:64px;height:64px;background:var(--teal-l);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 18px;font-size:1.8rem">📅</div><h3 style="font-family:var(--font-display);font-size:1.3rem;font-weight:700;color:var(--dark);margin-bottom:10px">0% Interest Finance</h3><p style="font-size:.84rem;color:var(--text2);line-height:1.65;margin-bottom:16px">Spread your treatment cost over 6, 12 or 24 months at 0% interest. Subject to credit status and eligibility.</p><div style="background:var(--teal-l);border-radius:var(--radius-lg);padding:10px 14px;font-size:.82rem;color:var(--teal-d);font-weight:600">6 / 12 / 24 months · 0% APR · Subject to status</div></div>
      <div class="card" data-aos="up" style="padding:32px;text-align:center"><div style="width:64px;height:64px;background:var(--teal-l);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 18px;font-size:1.8rem">🤝</div><h3 style="font-family:var(--font-display);font-size:1.3rem;font-weight:700;color:var(--dark);margin-bottom:10px">Extended Finance</h3><p style="font-size:.84rem;color:var(--text2);line-height:1.65;margin-bottom:16px">For larger procedure combinations, extended plans of up to 48 months are available at competitive rates.</p><div style="background:var(--teal-l);border-radius:var(--radius-lg);padding:10px 14px;font-size:.82rem;color:var(--teal-d);font-weight:600">Up to 48 months · Competitive APR</div></div>
    </div>
    <!-- Finance Example -->
    <div style="background:var(--dark2);border-radius:var(--radius-2xl);padding:36px;max-width:800px;margin:0 auto" data-aos="up">
      <h3 style="font-family:var(--font-display);font-size:1.4rem;color:#fff;margin-bottom:6px;text-align:center">Representative Finance Example</h3>
      <p style="font-size:.82rem;color:rgba(255,255,255,.5);text-align:center;margin-bottom:28px">Based on a FUE Hair Transplant at £1,999 (Premium package)</p>
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-bottom:20px">
        <div style="background:rgba(255,255,255,.07);border-radius:var(--radius-lg);padding:18px;text-align:center"><div style="font-size:.7rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:rgba(255,255,255,.45);margin-bottom:6px">6 Months · 0% APR</div><div style="font-size:2rem;font-weight:800;color:var(--gold)">£333</div><div style="font-size:.74rem;color:rgba(255,255,255,.4);margin-top:3px">per month</div></div>
        <div style="background:rgba(11,107,150,.3);border-radius:var(--radius-lg);padding:18px;text-align:center;border:1px solid rgba(11,107,150,.5)"><div style="font-size:.7rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:rgba(255,255,255,.65);margin-bottom:6px">12 Months · 0% APR</div><div style="font-size:2rem;font-weight:800;color:var(--gold)">£167</div><div style="font-size:.74rem;color:rgba(255,255,255,.5);margin-top:3px">per month</div></div>
        <div style="background:rgba(255,255,255,.07);border-radius:var(--radius-lg);padding:18px;text-align:center"><div style="font-size:.7rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:rgba(255,255,255,.45);margin-bottom:6px">24 Months · 0% APR</div><div style="font-size:2rem;font-weight:800;color:var(--gold)">£83</div><div style="font-size:.74rem;color:rgba(255,255,255,.4);margin-top:3px">per month</div></div>
      </div>
      <p style="font-size:.72rem;color:rgba(255,255,255,.3);text-align:center;line-height:1.6">Representative example only. Finance is subject to status and eligibility. 0% APR available for eligible applicants on approved terms.</p>
    </div>
  </div>
</section>

<!-- HOW PAYMENT WORKS -->
<section class="sec bg-off">
  <div class="container">
    <div class="sh center" data-aos="up" style="margin-bottom:44px"><span class="label label-teal">Payment Process</span><h2 class="disp-xl">How Payment <em style="font-style:italic">Works</em></h2></div>
    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:20px" data-aos="up">
      <div style="background:#fff;border-radius:var(--radius-xl);padding:24px;border:1px solid var(--border);text-align:center"><div style="width:48px;height:48px;background:var(--teal);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 14px;color:#fff;font-weight:800;font-size:.9rem">1</div><h4 style="font-weight:700;color:var(--dark);font-size:.9rem;margin-bottom:8px">Deposit</h4><p style="font-size:.8rem;color:var(--text2);line-height:1.6">Pay from £200 to confirm your booking and lock in your surgery date and surgeon.</p></div>
      <div style="background:#fff;border-radius:var(--radius-xl);padding:24px;border:1px solid var(--border);text-align:center"><div style="width:48px;height:48px;background:var(--teal);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 14px;color:#fff;font-weight:800;font-size:.9rem">2</div><h4 style="font-weight:700;color:var(--dark);font-size:.9rem;margin-bottom:8px">Finance (if applicable)</h4><p style="font-size:.8rem;color:var(--text2);line-height:1.6">Finance application processed at this stage. Decisions typically within 24–48 hours.</p></div>
      <div style="background:#fff;border-radius:var(--radius-xl);padding:24px;border:1px solid var(--border);text-align:center"><div style="width:48px;height:48px;background:var(--teal);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 14px;color:#fff;font-weight:800;font-size:.9rem">3</div><h4 style="font-weight:700;color:var(--dark);font-size:.9rem;margin-bottom:8px">Balance</h4><p style="font-size:.8rem;color:var(--text2);line-height:1.6">Remaining balance due 14 days before departure. All major cards and bank transfer accepted.</p></div>
      <div style="background:#fff;border-radius:var(--radius-xl);padding:24px;border:1px solid var(--border);text-align:center"><div style="width:48px;height:48px;background:var(--gold);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 14px;color:var(--dark);font-weight:800;font-size:.9rem">✓</div><h4 style="font-weight:700;color:var(--dark);font-size:.9rem;margin-bottom:8px">You Travel</h4><p style="font-size:.8rem;color:var(--text2);line-height:1.6">Everything fully paid before you leave. No cash, no on-site payments, no surprises.</p></div>
    </div>
  </div>
</section>

<!-- FAQ -->
<section class="sec">
  <div class="container">
    <div class="faq-layout">
      <div data-aos="left">
        <span class="label label-teal" style="display:block;margin-bottom:12px">Finance FAQs</span>
        <h2 class="disp-xl">Common Cost &amp; Finance <em style="font-style:italic">Questions</em></h2>
        <p class="body-lg" style="margin-bottom:24px">Transparent answers to the questions we hear most often about pricing and payment.</p>
        <div class="faq-cta-box"><h4>Need a personalised quote?</h4><p>Your free consultation includes a full written price breakdown with no commitment required.</p><a href="#" class="btn btn-primary open-modal">Get My Quote</a></div>
      </div>
      <div class="faq-list" data-aos="right">
        <div class="faq-item"><div class="faq-q">Are there any hidden costs?<div class="faq-icon"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg></div></div><div class="faq-a">Absolutely none. Every Elara Medical price is fully all-inclusive — covering your procedure, hotel, transfers, pre-op tests, medications and aftercare. The only items you pay independently are your flights and personal spending. We provide a full written cost breakdown before any commitment.</div></div>
        <div class="faq-item"><div class="faq-q">Can I get a firm price before booking?<div class="faq-icon"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg></div></div><div class="faq-a">Yes. Following your free consultation, your Case Manager provides a full written quote confirming every element. For surgical procedures, your surgeon may adjust this slightly following pre-operative medical assessment if clinical complexity differs — but this is always discussed transparently before you confirm.</div></div>
        <div class="faq-item"><div class="faq-q">What happens if I need to cancel or reschedule?<div class="faq-icon"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg></div></div><div class="faq-a">Cancellations made more than 30 days before your procedure date receive a full deposit refund. Cancellations within 30 days may forfeit the deposit. Rescheduling is available at no charge with 14 days' notice, subject to availability. Full terms are provided at booking.</div></div>
        <div class="faq-item"><div class="faq-q">Am I eligible for 0% finance?<div class="faq-icon"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg></div></div><div class="faq-a">Finance is available to UK residents aged 18+ with satisfactory credit status. Applications are assessed by our UK-regulated finance partner and decisions typically made within 24–48 hours. Eligibility cannot be guaranteed and is subject to individual assessment.</div></div>
        <div class="faq-item"><div class="faq-q">What payment methods do you accept?<div class="faq-icon"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg></div></div><div class="faq-a">We accept all major credit and debit cards (Visa, Mastercard, American Express), bank transfer (BACS/CHAPS), and approved finance arrangements. All card payments are processed through our PCI-DSS compliant payment processor.</div></div>
        <div class="faq-item"><div class="faq-q">Is my money protected?<div class="faq-icon"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg></div></div><div class="faq-a">Elara Medical Ltd operates under UK consumer protection law including the Consumer Rights Act. Card payments carry additional protection via your card provider's chargeback scheme. Our aftercare guarantee covers revision procedures in the event of clinical complications.</div></div>
      </div>
    </div>
  </div>
</section>

<!-- CTA -->
<section class="cta-banner">
  <div class="container">
    <h2 class="disp-xl" style="color:#fff">Ready to Get Your Personalised Quote?</h2>
    <p>Book your free consultation and receive a full written price breakdown within 24 hours — with no obligation to proceed.</p>
    <div class="cta-btns">
      <a href="#" class="btn btn-gold btn-xl open-modal">🗓 Book Free Consultation</a>
      <a href="tel:<?php echo esc_attr($phone_clean); ?>" class="btn btn-outline-white btn-xl">📞 <?php echo esc_html($phone); ?></a>
    </div>
  </div>
</section>

<script>
(function(){
  var wpData={hair:{procs:[{name:'FUE Hair Transplant',elara:1499,uk:9500,pkg:{essential:1499,premium:1799,elite:2299}},{name:'DHI Hair Transplant',elara:1899,uk:12000,pkg:{essential:1899,premium:2199,elite:2699}},{name:'Sapphire FUE',elara:1699,uk:10500,pkg:{essential:1699,premium:1999,elite:2499}},{name:'Beard Transplant',elara:1299,uk:5500,pkg:{essential:1299,premium:1599,elite:1999}}]},cosmetic:{procs:[{name:'Rhinoplasty',elara:2200,uk:7250,pkg:{essential:2200,premium:2600,elite:3200}},{name:'Breast Augmentation',elara:2800,uk:6500,pkg:{essential:2800,premium:3200,elite:3900}},{name:'Breast Lift',elara:2400,uk:6500,pkg:{essential:2400,premium:2800,elite:3400}},{name:'Tummy Tuck',elara:3200,uk:8000,pkg:{essential:3200,premium:3700,elite:4400}},{name:'Liposuction',elara:1800,uk:5250,pkg:{essential:1800,premium:2200,elite:2800}},{name:'Mummy Makeover',elara:5200,uk:20000,pkg:{essential:5200,premium:6200,elite:7500}}]},dental:{procs:[{name:'Dental Implant (single)',elara:499,uk:2750,pkg:{essential:499,premium:699,elite:899}},{name:'Hollywood Smile (full)',elara:2800,uk:20000,pkg:{essential:2800,premium:3400,elite:4200}},{name:'Porcelain Veneers (per 6)',elara:1194,uk:6600,pkg:{essential:1194,premium:1500,elite:1900}}]},weight:{procs:[{name:'Gastric Sleeve',elara:2800,uk:10000,pkg:{essential:2800,premium:3200,elite:3900}},{name:'Gastric Bypass',elara:3400,uk:12500,pkg:{essential:3400,premium:3900,elite:4700}},{name:'Gastric Balloon',elara:1400,uk:4000,pkg:{essential:1400,premium:1700,elite:2100}}]},eye:{procs:[{name:'LASIK (both eyes)',elara:798,uk:4000,pkg:{essential:798,premium:998,elite:1298}},{name:'SMILE (both eyes)',elara:1198,uk:5000,pkg:{essential:1198,premium:1498,elite:1898}},{name:'Lens Replacement (both)',elara:2400,uk:6000,pkg:{essential:2400,premium:2900,elite:3600}}]},mummy:{procs:[{name:'Breast Aug + Tummy Tuck',elara:5200,uk:15000,pkg:{essential:5200,premium:6200,elite:7500}},{name:'Full Makeover',elara:7200,uk:21000,pkg:{essential:7200,premium:8400,elite:10000}}]}};
  var wc=null,wp=null,wk=null;
  window.wpCat=function(cat,el){wc=cat;document.querySelectorAll('.wco').forEach(function(e){e.style.borderColor='var(--border)';e.style.background='#fff';});el.style.borderColor='var(--teal)';el.style.background='var(--teal-l)';var list=document.getElementById('wpProcList');list.innerHTML='';wpData[cat].procs.forEach(function(p,i){var d=document.createElement('div');d.style.cssText='padding:13px 16px;border:1.5px solid var(--border);border-radius:var(--radius-lg);cursor:pointer;display:flex;justify-content:space-between;align-items:center;font-size:.88rem;color:var(--text);font-weight:500;background:#fff;margin-bottom:4px;transition:all .2s;';d.innerHTML='<span>'+p.name+'</span><span style="color:var(--teal);font-weight:700;font-size:.84rem">From £'+p.elara.toLocaleString()+'</span>';d.onmouseover=function(){this.style.borderColor='var(--teal)';this.style.background='var(--teal-l)';};d.onmouseout=function(){if(wp!==i){this.style.borderColor='var(--border)';this.style.background='#fff';}};d.onclick=function(){wp=i;list.querySelectorAll('div').forEach(function(x){x.style.borderColor='var(--border)';x.style.background='#fff';});d.style.borderColor='var(--teal)';d.style.background='var(--teal-l)';setTimeout(function(){wpGoTo(3);},300);};list.appendChild(d);});setTimeout(function(){wpGoTo(2);},300);};
  window.wpPkg=function(pkg,el){wk=pkg;document.querySelectorAll('#wcp-3 .wco').forEach(function(e){e.style.borderColor='var(--border)';e.style.background='#fff';});el.style.borderColor='var(--teal)';el.style.background='var(--teal-l)';setTimeout(function(){wpShowResult();},300);};
  function wpShowResult(){var p=wpData[wc].procs[wp];var price=p.pkg[wk];var uk=p.uk;var save=uk-price;var pct=Math.round((save/uk)*100);document.getElementById('wp-title').textContent=p.name+' · '+wk.charAt(0).toUpperCase()+wk.slice(1)+' Package';document.getElementById('wp-price').textContent='£'+price.toLocaleString();document.getElementById('wp-uk').textContent='£'+uk.toLocaleString();document.getElementById('wp-save').textContent='£'+save.toLocaleString();document.getElementById('wp-pct').textContent=pct+'% saving vs UK';document.getElementById('wp-monthly').textContent='£'+Math.round(price/12)+'/month';wpGoTo(4);}
  function wpGoTo(n){document.querySelectorAll('.wcp').forEach(function(p){p.style.display='none';});var panel=document.getElementById('wcp-'+n);if(panel)panel.style.display='block';document.querySelectorAll('.wpcalc-step').forEach(function(s){if(parseInt(s.dataset.s)===n){s.style.color='var(--teal)';s.style.borderBottom='3px solid var(--teal)';}else{s.style.color='var(--text3)';s.style.borderBottom='3px solid transparent';}});}
  window.wpBack=function(n){wpGoTo(n);};
  window.wpReset=function(){wc=null;wp=null;wk=null;document.querySelectorAll('.wco').forEach(function(e){e.style.borderColor='var(--border)';e.style.background='#fff';});wpGoTo(1);};
  window.wpFilterPricing=function(btn,cat){document.querySelectorAll('.fbtn[onclick*="wpFilterPricing"]').forEach(function(b){b.classList.remove('on');});btn.classList.add('on');document.querySelectorAll('#wpPricingBody tr[data-wpc]').forEach(function(r){r.style.display=(cat==='all'||r.dataset.wpc===cat)?'':'none';});};
})();
</script>

<?php get_footer();
