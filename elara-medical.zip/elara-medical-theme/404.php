<?php get_header(); ?>
<main style="padding:200px 0 120px;text-align:center;min-height:70vh;background:var(--grad)">
  <div class="container">
    <div style="font-size:6rem;font-weight:800;background:var(--grad-gold);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;line-height:1;margin-bottom:16px">404</div>
    <h1 style="font-family:var(--font-display);font-size:2.5rem;color:#fff;margin-bottom:16px">Page Not Found</h1>
    <p style="color:rgba(255,255,255,.65);font-size:1.05rem;max-width:480px;margin:0 auto 36px;line-height:1.7">The page you're looking for doesn't exist or has been moved. Let us help you find what you need.</p>
    <div style="display:flex;justify-content:center;gap:12px;flex-wrap:wrap">
      <a href="<?php echo esc_url(home_url('/')); ?>" class="btn btn-gold btn-lg">← Go Home</a>
      <a href="#" class="btn btn-outline-white btn-lg open-modal">Book Free Consultation</a>
    </div>
  </div>
</main>
<?php get_footer();
