<?php /* Template Name: FAQ */ get_header(); ?>
<div class="page-hero"><div class="container"><div>
<div class="ph-breadcrumb"><a href="<?php echo home_url('/'); ?>">Home</a><span>›</span><span>FAQ</span></div>
<h1 class="disp-xl ph-h1">Your Questions, <em style="font-style:italic">Answered Honestly.</em></h1>
<p class="ph-sub">We believe in complete transparency. Here is every question we hear from patients — answered without spin or jargon.</p>
<div class="ph-ctas"><a href="#" class="btn btn-gold btn-lg open-modal">Ask Us Directly</a></div>
</div></div></div>
<section class="sec"><div class="container">
<div style="display:grid;grid-template-columns:1fr 1fr;gap:48px">
<div>
<div style="font-size:.72rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--teal);margin-bottom:14px;padding-bottom:10px;border-bottom:2px solid var(--teal-l)">General</div>
<div class="faq-list">
<div class="faq-item"><div class="faq-q">What exactly is Elara Medical?<div class="faq-icon"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg></div></div><div class="faq-a">Elara Medical is a UK-registered medical tourism facilitator. We act as a trusted intermediary between British patients and Istanbul's finest accredited medical facilities — vetting, booking and coordinating your entire treatment journey including logistics, translations and aftercare.</div></div>
<div class="faq-item"><div class="faq-q">Is Elara Medical a UK-registered company?<div class="faq-icon"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg></div></div><div class="faq-a">Yes. Elara Medical Ltd is registered in England and Wales and operates fully within UK consumer protection law. Our London office is staffed Monday–Saturday and our team is fully accountable to British regulatory standards.</div></div>
<div class="faq-item"><div class="faq-q">Can I bring a companion with me?<div class="faq-icon"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg></div></div><div class="faq-a">Absolutely — we actively encourage it. We regularly accommodate patients travelling with a partner, friend or family member and can arrange hotel accommodation for your companion at the same property.</div></div>
</div>
<div style="font-size:.72rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--teal);margin:28px 0 14px;padding-bottom:10px;border-bottom:2px solid var(--teal-l)">Safety &amp; Medical</div>
<div class="faq-list">
<div class="faq-item"><div class="faq-q">How safe is surgery in Istanbul?<div class="faq-icon"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg></div></div><div class="faq-a">Istanbul's JCI-accredited hospitals meet identical international safety standards to the UK's leading private hospitals. Our partner clinics undergo rigorous annual audits, and all surgeons hold international board certification. We personally audit every facility before adding it to our network.</div></div>
<div class="faq-item"><div class="faq-q">Who will perform my surgery?<div class="faq-icon"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg></div></div><div class="faq-a">You will be assigned a named, board-certified specialist surgeon chosen specifically for your procedure. We provide their full credentials and patient rating before you confirm your booking. You will have a pre-operative consultation with your surgeon before the procedure begins.</div></div>
<div class="faq-item"><div class="faq-q">What if I experience complications?<div class="faq-icon"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg></div></div><div class="faq-a">All Elara Medical patients are covered by our aftercare guarantee. In the rare event of complications, we coordinate directly with your treating surgeon, arrange urgent follow-up appointments, and in exceptional circumstances cover revision procedures at no cost to the patient.</div></div>
</div>
</div>
<div>
<div style="font-size:.72rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--teal);margin-bottom:14px;padding-bottom:10px;border-bottom:2px solid var(--teal-l)">Costs &amp; Packages</div>
<div class="faq-list">
<div class="faq-item"><div class="faq-q">What does "all-inclusive" actually include?<div class="faq-icon"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg></div></div><div class="faq-a">Your package covers: the procedure, pre-operative medical tests, 4 or 5-star hotel accommodation, VIP airport and clinic transfers, personal patient coordinator, translation services, post-operative medications and 12-month UK aftercare support. Flights and personal spending are the only exclusions.</div></div>
<div class="faq-item"><div class="faq-q">Are there any hidden costs?<div class="faq-icon"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg></div></div><div class="faq-a">Never. We have a strict no-hidden-costs policy. Before you confirm, you receive a detailed written quote covering every element. The only variable is your flight cost, which you book independently — we provide guidance on routes and timing.</div></div>
<div class="faq-item"><div class="faq-q">Do you offer finance or payment plans?<div class="faq-icon"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg></div></div><div class="faq-a">Yes. We have partnered with a UK-regulated finance provider to offer 0% interest payment plans for eligible patients. Please ask your advisor for details during your consultation.</div></div>
</div>
<div style="font-size:.72rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--teal);margin:28px 0 14px;padding-bottom:10px;border-bottom:2px solid var(--teal-l)">Aftercare &amp; Recovery</div>
<div class="faq-list">
<div class="faq-item"><div class="faq-q">When will I see my full results?<div class="faq-icon"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg></div></div><div class="faq-a">Hair transplants: full results at 12–14 months. Rhinoplasty: swelling fully resolved at 6–12 months. Breast surgery: stable at 6–8 weeks. Dental: immediate. Weight loss: ongoing over 12–24 months. Eye surgery: full stability within 2–4 weeks.</div></div>
<div class="faq-item"><div class="faq-q">When can I return to work?<div class="faq-icon"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg></div></div><div class="faq-a">Most desk-based workers return within 5–10 days. Physically demanding roles should allow 2–4 weeks. Your surgeon will provide a personalised return-to-work guidance letter before discharge.</div></div>
<div class="faq-item"><div class="faq-q">What UK aftercare support is provided?<div class="faq-icon"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg></div></div><div class="faq-a">Your dedicated UK patient coordinator checks in at 1 week, 1 month, 3, 6 and 12 months post-procedure. They are also available by phone, email or WhatsApp at any time between these check-ins.</div></div>
</div>
</div>
</div>
<div style="background:var(--teal-l);border-radius:var(--radius-2xl);padding:48px;text-align:center;margin-top:56px;border:1px solid rgba(11,107,150,.2)" data-aos="up">
<h3 style="font-family:var(--font-display);font-size:1.8rem;font-weight:700;color:var(--dark);margin-bottom:12px">Still Have Questions?</h3>
<p style="color:var(--text2);font-size:.97rem;max-width:520px;margin:0 auto 28px;line-height:1.7">Our specialist advisors are available 7 days a week — phone, email, WhatsApp or free consultation.</p>
<div style="display:flex;justify-content:center;gap:12px;flex-wrap:wrap">
<a href="#" class="btn btn-primary btn-lg open-modal">Book Free Consultation</a>
<a href="tel:<?php echo esc_attr(str_replace(' ','',elara_phone())); ?>" class="btn btn-outline btn-lg">📞 <?php echo esc_html(elara_phone()); ?></a>
</div>
</div>
</div></section>
<?php get_footer();
