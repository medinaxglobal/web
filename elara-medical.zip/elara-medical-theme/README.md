# Elara Medical — WordPress Theme

## Quick Setup on Hostinger

### Step 1: Install WordPress
- Log in to Hostinger hPanel
- Go to Website > Auto Installer > WordPress
- Install WordPress on your domain
- Note your admin username and password

### Step 2: Upload & Activate Theme
- Log in to WordPress Admin (yourdomain.com/wp-admin)
- Go to Appearance > Themes > Add New > Upload Theme
- Upload the elara-medical.zip file
- Click Install Now, then Activate

### Step 3: Create Pages (IMPORTANT)
Create the following pages in WordPress Admin > Pages > Add New.
For each page, set the correct Page Template in the right sidebar under "Page Attributes > Template".

| Page Title       | Slug              | Template              |
|-----------------|-------------------|-----------------------|
| Home            | (set as front page)| Home Page            |
| About Us        | about-us          | About Us              |
| Hair Transplant  | hair-transplant   | Hair Transplant       |
| Cosmetic Surgery | cosmetic-surgery  | Cosmetic Surgery      |
| Dental Treatments| dental-treatments | Dental Treatments     |
| Weight Loss      | weight-loss       | Weight Loss Surgery   |
| Eye Treatments   | eye-treatments    | Eye Treatments        |
| Locations        | locations         | Locations             |
| Patient Stories  | patient-stories   | Patient Stories       |
| Pricing          | pricing           | Pricing               |
| Blog             | blog              | Blog Hub              |
| FAQ              | faq               | FAQ                   |
| Contact          | contact           | Contact               |

### Step 4: Set Homepage
- Go to Settings > Reading
- Select "A static page"
- Set Front page to: Home
- Set Posts page to: Blog
- Save Changes

### Step 5: Set Site Name & Contact Details
- Go to Appearance > Customize > Site Identity
- Set Site Title: Elara Medical (or your brand name)
- Set phone number, email and WhatsApp number
- Publish changes

### Step 6: Recommended Plugins
Install these free plugins from Plugins > Add New:
- Yoast SEO (SEO optimization)
- WP Super Cache (speed)
- Smush (image compression)
- Contact Form 7 (optional - for advanced forms)
- UpdraftPlus (backups)

### Step 7: Replace Placeholder Content
- Replace all Unsplash images with your own patient photos
- Update phone numbers, email and WhatsApp in Appearance > Customize
- Add your real Trustpilot review widget
- Update all pricing to match your actual rates
- Add your company registration number in footer.php

### Customizing Colors
All colors are CSS variables in assets/css/elara.css (line 1-20).
Change --teal, --gold etc. to match your brand.

## Support
Theme developed for Elara Medical Ltd.
