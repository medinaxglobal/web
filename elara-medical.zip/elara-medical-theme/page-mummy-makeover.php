<?php
/**
 * Template Name: Mummy Makeover
 * @package elara-medical
 */
get_header();
$phone = elara_phone();
$phone_clean = str_replace(' ', '', $phone);
?>

<!-- HERO -->
<div class="page-hero">
  <div class="container">
    <div>
      <div class="ph-breadcrumb">
        <a href="<?php echo esc_url(home_url('/')); ?>">Home</a><span>›</span>
        <a href="<?php echo esc_url(elara_page_url('cosmetic-surgery')); ?>">Cosmetic Surgery</a><span>›</span>
        <span>Mummy Makeover</span>
      </div>
      <div class="ph-tags">
        <span class="badge badge-white">Body Contouring</span>
        <span class="badge badge-white">Breast Surgery</span>
        <span class="badge badge-white">Tummy Tuck</span>
        <span class="badge badge-white">Liposuction</span>
      </div>
      <h1 class="disp-xl ph-h1">Mummy Makeover in Istanbul — <em style="font-style:italic">Reclaim Your Body. Rediscover Your Confidence.</em></h1>
      <p class="ph-sub">A carefully tailored combination of breast, abdominal and body contouring procedures — designed to restore the figure you had before pregnancy and breastfeeding, in a single all-inclusive Istanbul visit.</p>
      <div class="ph-ctas">
        <a href="#" class="btn btn-gold btn-lg open-modal">Book Free Consultation</a>
        <a href="#mm-gallery" class="btn btn-outline-white btn-lg">View Before &amp; After</a>
      </div>
    </div>
    <div class="ph-right">
      <h4>Quick Facts</h4>
      <div class="quick-list">
        <div class="ql-item"><span class="ql-icon">💷</span>From £5,200 all-inclusive</div>
        <div class="ql-item"><span class="ql-icon">✈</span>6–8 night Istanbul stay</div>
        <div class="ql-item"><span class="ql-icon">🕒</span>3–6 hour combined procedure</div>
        <div class="ql-item"><span class="ql-icon">💊</span>General anaesthesia</div>
        <div class="ql-item"><span class="ql-icon">🏥</span>JCI-accredited hospital</div>
        <div class="ql-item"><span class="ql-icon">📅</span>Final results: 3–6 months</div>
        <div class="ql-item"><span class="ql-icon">📞</span>UK aftercare included</div>
      </div>
    </div>
  </div>
</div>

<!-- MAIN CONTENT -->
<section class="sec">
  <div class="container">
    <div class="treatment-detail-grid">

      <!-- LEFT: CONTENT -->
      <div class="treatment-content">

        <h2>What Is a Mummy Makeover?</h2>
        <p>A mummy makeover is not a single operation — it is a personalised combination of surgical procedures designed to address the physical changes that pregnancy, childbirth and breastfeeding bring to a woman's body. Most commonly, it targets the breasts, abdomen and waistline, though every treatment plan is tailored uniquely to the individual patient's goals.</p>
        <p>It is worth noting that a mummy makeover is not exclusively for mothers. Anyone who has experienced significant weight loss or changes to their body shape may be an excellent candidate — the underlying surgical principles apply equally.</p>
        <p>Importantly, a mummy makeover is a body <em>reshaping</em> procedure, not a weight loss solution. Candidates are generally advised to be at or close to their ideal, stable weight before proceeding.</p>

        <!-- QUICK FACTS BOXES -->
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin:28px 0">
          <div style="background:var(--teal-l);border-radius:var(--radius-xl);padding:20px;border:1px solid rgba(11,107,150,.18)"><div style="font-size:1.6rem;margin-bottom:8px">⏱</div><div style="font-weight:700;color:var(--dark);font-size:.9rem;margin-bottom:4px">Recovery Time</div><div style="font-size:.84rem;color:var(--text2);line-height:1.6">Most patients return to desk-based work within 2–3 weeks. Full physical activity typically resumes at 6–8 weeks post-surgery.</div></div>
          <div style="background:var(--teal-l);border-radius:var(--radius-xl);padding:20px;border:1px solid rgba(11,107,150,.18)"><div style="font-size:1.6rem;margin-bottom:8px">🌟</div><div style="font-weight:700;color:var(--dark);font-size:.9rem;margin-bottom:4px">Final Results</div><div style="font-size:.84rem;color:var(--text2);line-height:1.6">Full results become visible at 3–6 months once all post-operative swelling has resolved. Early improvements are noticeable from week 4–6.</div></div>
          <div style="background:var(--gold-l);border-radius:var(--radius-xl);padding:20px;border:1px solid rgba(200,152,42,.2)"><div style="font-size:1.6rem;margin-bottom:8px">💉</div><div style="font-weight:700;color:var(--dark);font-size:.9rem;margin-bottom:4px">Anaesthesia</div><div style="font-size:.84rem;color:var(--text2);line-height:1.6">Performed under general anaesthesia administered by a consultant anaesthetist. You will be completely asleep throughout the procedure.</div></div>
          <div style="background:var(--gold-l);border-radius:var(--radius-xl);padding:20px;border:1px solid rgba(200,152,42,.2)"><div style="font-size:1.6rem;margin-bottom:8px">✨</div><div style="font-weight:700;color:var(--dark);font-size:.9rem;margin-bottom:4px">Longevity of Results</div><div style="font-size:.84rem;color:var(--text2);line-height:1.6">Results are long-lasting when maintained with a stable weight. Natural ageing and significant weight changes can affect the outcome over time.</div></div>
        </div>

        <h2>What's Included in a Mummy Makeover?</h2>
        <p>Your mummy makeover package is built around your specific concerns. While the most common combination addresses the breasts and abdomen, your final treatment plan is decided during your pre-operative consultation.</p>

        <!-- TABS -->
        <div style="display:flex;gap:0;border-bottom:2px solid var(--border);margin:24px 0 20px" id="mmTabs">
          <button onclick="switchTab('breast',this)" class="mm-tab" style="padding:12px 22px;font-size:.88rem;font-weight:600;color:var(--teal);border:none;background:none;cursor:pointer;border-bottom:3px solid var(--teal);margin-bottom:-2px">💪 Breast Surgery</button>
          <button onclick="switchTab('lipo',this)" class="mm-tab" style="padding:12px 22px;font-size:.88rem;font-weight:600;color:var(--text2);border:none;background:none;cursor:pointer;border-bottom:3px solid transparent;margin-bottom:-2px">💧 Liposuction</button>
          <button onclick="switchTab('tummy',this)" class="mm-tab" style="padding:12px 22px;font-size:.88rem;font-weight:600;color:var(--text2);border:none;background:none;cursor:pointer;border-bottom:3px solid transparent;margin-bottom:-2px">✂️ Tummy Tuck</button>
        </div>

        <!-- Breast Tab -->
        <div id="tab-breast" class="mm-panel">
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:18px">
            <div style="background:var(--off);border-radius:var(--radius-lg);padding:18px;border:1px solid var(--border)"><h4 style="font-weight:700;color:var(--dark);font-size:.9rem;margin-bottom:7px">👙 Breast Augmentation</h4><p style="font-size:.82rem;color:var(--text2);line-height:1.6">If you have experienced significant volume loss following breastfeeding, implants can restore fullness and projection. All sizes and profiles available.</p></div>
            <div style="background:var(--off);border-radius:var(--radius-lg);padding:18px;border:1px solid var(--border)"><h4 style="font-weight:700;color:var(--dark);font-size:.9rem;margin-bottom:7px">⬆️ Breast Lift (Mastopexy)</h4><p style="font-size:.82rem;color:var(--text2);line-height:1.6">If sagging is your primary concern, a mastopexy alone repositions breast tissue and nipple for a more youthful appearance without implants.</p></div>
            <div style="background:var(--teal-l);border-radius:var(--radius-lg);padding:18px;border:1px solid rgba(11,107,150,.2)"><h4 style="font-weight:700;color:var(--teal-d);font-size:.9rem;margin-bottom:7px">✨ Augmentation + Lift</h4><p style="font-size:.82rem;color:var(--text2);line-height:1.6">The most commonly requested combination — restoring volume AND elevation. Ideal for post-breastfeeding changes.</p></div>
            <div style="background:var(--off);border-radius:var(--radius-lg);padding:18px;border:1px solid var(--border)"><h4 style="font-weight:700;color:var(--dark);font-size:.9rem;margin-bottom:7px">⬇️ Breast Reduction</h4><p style="font-size:.82rem;color:var(--text2);line-height:1.6">If pregnancy increased breast volume causing discomfort, a reduction achieves a smaller, better-supported, more proportionate result.</p></div>
          </div>
        </div>

        <!-- Lipo Tab -->
        <div id="tab-lipo" class="mm-panel" style="display:none">
          <p style="color:var(--text2);line-height:1.8;margin-bottom:18px;font-size:.93rem">Pregnancy often leaves stubborn fat deposits that don't respond to diet or exercise. Liposuction permanently removes these pockets to reveal a sculpted silhouette.</p>
          <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:18px">
            <div style="background:var(--off);border-radius:var(--radius-lg);padding:14px;border:1px solid var(--border);text-align:center"><div style="font-size:1.3rem;margin-bottom:6px">🫁</div><div style="font-weight:700;color:var(--dark);font-size:.82rem">Abdomen</div></div>
            <div style="background:var(--off);border-radius:var(--radius-lg);padding:14px;border:1px solid var(--border);text-align:center"><div style="font-size:1.3rem;margin-bottom:6px">⬅️➡️</div><div style="font-weight:700;color:var(--dark);font-size:.82rem">Flanks / Love Handles</div></div>
            <div style="background:var(--off);border-radius:var(--radius-lg);padding:14px;border:1px solid var(--border);text-align:center"><div style="font-size:1.3rem;margin-bottom:6px">🦵</div><div style="font-weight:700;color:var(--dark);font-size:.82rem">Thighs &amp; Hips</div></div>
            <div style="background:var(--off);border-radius:var(--radius-lg);padding:14px;border:1px solid var(--border);text-align:center"><div style="font-size:1.3rem;margin-bottom:6px">💪</div><div style="font-weight:700;color:var(--dark);font-size:.82rem">Upper Arms</div></div>
            <div style="background:var(--off);border-radius:var(--radius-lg);padding:14px;border:1px solid var(--border);text-align:center"><div style="font-size:1.3rem;margin-bottom:6px">🍑</div><div style="font-weight:700;color:var(--dark);font-size:.82rem">Back / Bra Line</div></div>
            <div style="background:var(--teal-l);border-radius:var(--radius-lg);padding:14px;border:1px solid rgba(11,107,150,.2);text-align:center"><div style="font-size:1.3rem;margin-bottom:6px">✨</div><div style="font-weight:700;color:var(--teal);font-size:.82rem">Custom Areas</div></div>
          </div>
        </div>

        <!-- Tummy Tab -->
        <div id="tab-tummy" class="mm-panel" style="display:none">
          <p style="color:var(--text2);line-height:1.8;margin-bottom:18px;font-size:.93rem">A tummy tuck removes loose stretched skin and repairs separated abdominal muscles — an extremely common consequence of pregnancy that exercise alone cannot fix.</p>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:18px">
            <div style="background:var(--off);border-radius:var(--radius-lg);padding:18px;border:1px solid var(--border)"><h4 style="font-weight:700;color:var(--dark);font-size:.9rem;margin-bottom:7px">✂️ Full Tummy Tuck</h4><p style="font-size:.82rem;color:var(--text2);line-height:1.6">Removes excess skin from navel to pubic hairline, repositions the belly button and tightens the abdominal muscles. Best for significant skin laxity.</p></div>
            <div style="background:var(--off);border-radius:var(--radius-lg);padding:18px;border:1px solid var(--border)"><h4 style="font-weight:700;color:var(--dark);font-size:.9rem;margin-bottom:7px">✂️ Mini Tummy Tuck</h4><p style="font-size:.82rem;color:var(--text2);line-height:1.6">Addresses only the lower abdominal area below the navel. Suitable for patients with mild to moderate skin laxity and good upper abdominal tone.</p></div>
          </div>
          <div style="background:var(--dark2);border-radius:var(--radius-lg);padding:18px 20px"><h4 style="color:#fff;font-size:.9rem;font-weight:700;margin-bottom:8px">🔍 Diastasis Recti (Muscle Separation) Repair</h4><p style="font-size:.82rem;color:rgba(255,255,255,.65);line-height:1.65">Many women experience separation of the rectus abdominis muscles during pregnancy. This causes the characteristic post-pregnancy pouch that no amount of exercise will fully resolve. Your surgeon repairs these muscles during the tummy tuck — dramatically improving your abdominal contour.</p></div>
        </div>

        <h2>Am I a Good Candidate?</h2>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:24px">
          <div style="background:#F0FDF4;border-radius:var(--radius-xl);padding:20px;border:1px solid #BBF7D0">
            <h4 style="color:#166534;font-size:.88rem;font-weight:700;margin-bottom:10px">✅ You may be ideal if you:</h4>
            <ul style="display:flex;flex-direction:column;gap:7px">
              <li style="display:flex;align-items:flex-start;gap:7px;font-size:.82rem;color:#166534"><span>✓</span>Have completed your family</li>
              <li style="display:flex;align-items:flex-start;gap:7px;font-size:.82rem;color:#166534"><span>✓</span>Are at or near a stable, healthy weight</li>
              <li style="display:flex;align-items:flex-start;gap:7px;font-size:.82rem;color:#166534"><span>✓</span>Are a non-smoker (or willing to stop)</li>
              <li style="display:flex;align-items:flex-start;gap:7px;font-size:.82rem;color:#166534"><span>✓</span>Have realistic expectations</li>
              <li style="display:flex;align-items:flex-start;gap:7px;font-size:.82rem;color:#166534"><span>✓</span>Have skin laxity or volume changes from pregnancy</li>
            </ul>
          </div>
          <div style="background:#FFF7ED;border-radius:var(--radius-xl);padding:20px;border:1px solid #FED7AA">
            <h4 style="color:#92400E;font-size:.88rem;font-weight:700;margin-bottom:10px">⚠️ Discuss with us first if you:</h4>
            <ul style="display:flex;flex-direction:column;gap:7px">
              <li style="display:flex;align-items:flex-start;gap:7px;font-size:.82rem;color:#92400E"><span>•</span>Plan to have further pregnancies</li>
              <li style="display:flex;align-items:flex-start;gap:7px;font-size:.82rem;color:#92400E"><span>•</span>Are still breastfeeding or recently stopped</li>
              <li style="display:flex;align-items:flex-start;gap:7px;font-size:.82rem;color:#92400E"><span>•</span>Have a BMI significantly over 30</li>
              <li style="display:flex;align-items:flex-start;gap:7px;font-size:.82rem;color:#92400E"><span>•</span>Have significant uncontrolled medical conditions</li>
              <li style="display:flex;align-items:flex-start;gap:7px;font-size:.82rem;color:#92400E"><span>•</span>Are taking blood-thinning medications</li>
            </ul>
          </div>
        </div>

        <h2>Recovery Timeline</h2>
        <div style="position:relative;padding-left:28px;border-left:3px solid var(--teal-l)">
          <?php
          $timeline = [
            ['Days 1–3', 'Hospital &amp; Initial Recovery', 'You remain in hospital for 1–2 nights for monitoring. Some discomfort, swelling and bruising is normal. A compression garment is fitted.', 'teal'],
            ['Days 4–7', 'Hotel Rest &amp; Check-Up', 'You rest at your hotel. A post-operative check-up is conducted. Drains are typically removed by day 3–5. Light walking is encouraged.', 'teal'],
            ['Week 2', 'Return Home', 'Most patients are cleared to fly home. Swelling continues to reduce. Continue wearing your compression garment and following aftercare instructions.', 'teal'],
            ['Weeks 3–6', 'Gradual Return to Normal', 'Most desk-based workers return to work around week 2–3. Your UK Elara Medical coordinator checks in at week 3 and week 6.', 'teal'],
            ['3–6 Months', 'Full Results', 'All swelling has resolved and your final result is visible. Scars continue to fade for up to 18 months. Final review at your 6-month milestone.', 'gold'],
          ];
          foreach ($timeline as $step):
            $color = $step[3] === 'gold' ? 'var(--gold)' : 'var(--teal)';
            $bg = $step[3] === 'gold' ? 'var(--gold-l)' : 'var(--off)';
            $border = $step[3] === 'gold' ? 'rgba(200,152,42,.25)' : 'var(--border)';
          ?>
          <div style="margin-bottom:16px;position:relative">
            <div style="position:absolute;left:-37px;width:20px;height:20px;background:<?php echo $color; ?>;border-radius:50%;border:3px solid #fff;box-shadow:0 0 0 2px <?php echo $color; ?>"></div>
            <div style="background:<?php echo $bg; ?>;border-radius:var(--radius-lg);padding:15px 17px;border:1px solid <?php echo $border; ?>">
              <div style="font-weight:700;color:<?php echo $color; ?>;font-size:.78rem;text-transform:uppercase;letter-spacing:.06em;margin-bottom:3px"><?php echo $step[0]; ?> · <?php echo $step[1]; ?></div>
              <p style="font-size:.82rem;color:var(--text2);line-height:1.6;margin:0"><?php echo $step[2]; ?></p>
            </div>
          </div>
          <?php endforeach; ?>
        </div>

        <!-- BEFORE AFTER GALLERY -->
        <div id="mm-gallery" style="margin-top:40px">
          <h2>Before &amp; After Results</h2>
          <p>Real results from Elara Medical patients who have undergone mummy makeover procedures. All photos are shared with full patient consent and are completely unedited.</p>
          <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:16px;margin:20px 0">
            <div class="ba-card"><div class="ba-imgs"><div class="ba-side"><img src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=300&q=70" alt="Before mummy makeover" loading="lazy"><span class="ba-lbl">Before</span></div><div class="ba-side"><img src="https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=300&q=70" alt="After mummy makeover" loading="lazy"><span class="ba-lbl">After</span></div></div><div class="ba-meta"><strong>Mummy Makeover</strong><span>Breast aug + tummy tuck + lipo · 5 months</span></div></div>
            <div class="ba-card"><div class="ba-imgs"><div class="ba-side"><img src="https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=300&q=70" alt="Before" loading="lazy"><span class="ba-lbl">Before</span></div><div class="ba-side"><img src="https://images.unsplash.com/photo-1512290923902-8a9f81dc236c?w=300&q=70" alt="After" loading="lazy"><span class="ba-lbl">After</span></div></div><div class="ba-meta"><strong>Breast Lift + Tummy Tuck</strong><span>No implants · 4 months post-op</span></div></div>
            <div class="ba-card"><div class="ba-imgs"><div class="ba-side"><img src="https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb?w=300&q=70" alt="Before" loading="lazy"><span class="ba-lbl">Before</span></div><div class="ba-side"><img src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&q=70" alt="After" loading="lazy"><span class="ba-lbl">After</span></div></div><div class="ba-meta"><strong>Augmentation + Liposuction</strong><span>Flanks &amp; abdomen · 6 months</span></div></div>
          </div>
        </div>

        <!-- PRICING TABLE -->
        <h2>Mummy Makeover Cost: Istanbul vs UK</h2>
        <div style="overflow:hidden;border-radius:var(--radius-xl);margin:18px 0">
          <table class="comp-table" style="width:100%">
            <thead><tr><th>Procedure Combination</th><th>UK Private Average</th><th style="background:var(--teal)">Elara Medical</th><th>You Save</th></tr></thead>
            <tbody>
              <tr><td>Breast Aug + Tummy Tuck</td><td>£12,000–£18,000</td><td class="comp-highlight"><strong style="color:var(--teal)">From £5,200</strong></td><td><strong>Up to £12,800</strong></td></tr>
              <tr><td>Breast Aug + Lift + Tummy Tuck</td><td>£14,000–£22,000</td><td class="comp-highlight"><strong style="color:var(--teal)">From £6,500</strong></td><td><strong>Up to £15,500</strong></td></tr>
              <tr><td>Full Makeover (Breast + TT + Lipo)</td><td>£16,000–£26,000</td><td class="comp-highlight"><strong style="color:var(--teal)">From £7,200</strong></td><td><strong>Up to £18,800</strong></td></tr>
              <tr><td>Breast Reduction + Tummy Tuck</td><td>£13,000–£19,000</td><td class="comp-highlight"><strong style="color:var(--teal)">From £5,800</strong></td><td><strong>Up to £13,200</strong></td></tr>
            </tbody>
          </table>
        </div>
        <p style="font-size:.76rem;color:var(--text3)">*All Elara Medical prices include hotel, VIP transfers, pre-op tests, medications &amp; 12-month aftercare.</p>

        <!-- FAQ -->
        <h2 style="margin-top:32px">Frequently Asked Questions</h2>
        <div class="faq-list">
          <div class="faq-item"><div class="faq-q">Can I have a mummy makeover if I plan to have more children?<div class="faq-icon"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg></div></div><div class="faq-a">Technically yes, but it is strongly advised to complete your family first. A subsequent pregnancy will stretch the abdominal skin and may separate the repaired muscles — reversing the surgical results. We always discuss family planning during consultation.</div></div>
          <div class="faq-item"><div class="faq-q">How long do I need to stay in Istanbul?<div class="faq-icon"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg></div></div><div class="faq-a">We recommend planning for 7–8 nights. This covers 1–2 nights in hospital, 5–6 nights of hotel recovery, and clearance from your surgeon before flying home. More extensive combinations may require a slightly longer stay.</div></div>
          <div class="faq-item"><div class="faq-q">Will I have visible scars?<div class="faq-icon"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg></div></div><div class="faq-a">All surgery results in scars, but your surgeon places incisions strategically within the natural bikini line, making them easily concealed under underwear and swimwear. Scars fade significantly over 12–18 months and full scar management guidance is provided.</div></div>
          <div class="faq-item"><div class="faq-q">Can I combine a mummy makeover with other procedures?<div class="faq-icon"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg></div></div><div class="faq-a">Additional procedures like a BBL, arm lift or thigh lift may be possible. However, surgical safety is the priority — our surgeons advise on the maximum safe combination for a single anaesthetic session and may recommend staging additional procedures if required.</div></div>
          <div class="faq-item"><div class="faq-q">How soon can I exercise after a mummy makeover?<div class="faq-icon"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg></div></div><div class="faq-a">Light walking from day 3. Gentle low-impact activity from weeks 4–6. Core exercises, weight training and high-impact activities should not resume until approximately 8–10 weeks, or when specifically cleared by your surgeon.</div></div>
          <div class="faq-item"><div class="faq-q">Is it safe to travel to Istanbul for this procedure?<div class="faq-icon"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg></div></div><div class="faq-a">All our partner hospitals are JCI-accredited, meeting the same international safety benchmarks as the UK's leading private hospitals. Your procedure is performed by a board-certified plastic surgeon. Our aftercare guarantee covers any complications that may arise.</div></div>
        </div>

      </div><!-- /content -->

      <!-- SIDEBAR -->
      <div class="td-sidebar">
        <div class="td-cta-card">
          <h4>Book Your Free Consultation</h4>
          <p>Speak with a specialist body contouring advisor — completely free and zero obligation.</p>
          <a href="#" class="btn btn-gold open-modal" style="width:100%;justify-content:center;display:flex;margin-bottom:10px">Book Free Consultation</a>
          <a href="tel:<?php echo esc_attr($phone_clean); ?>" class="btn btn-outline-white" style="width:100%;justify-content:center;display:flex">📞 <?php echo esc_html($phone); ?></a>
        </div>
        <div class="td-price-card">
          <h5>Starting Prices</h5>
          <div class="tdp-item"><span class="tdp-name">Breast Aug + Tummy Tuck</span><span class="tdp-price">From £5,200</span></div>
          <div class="tdp-item"><span class="tdp-name">Aug + Lift + Tummy Tuck</span><span class="tdp-price">From £6,500</span></div>
          <div class="tdp-item"><span class="tdp-name">Full Makeover (+ Lipo)</span><span class="tdp-price">From £7,200</span></div>
          <div class="tdp-item"><span class="tdp-name">Reduction + Tummy Tuck</span><span class="tdp-price">From £5,800</span></div>
          <p style="font-size:.72rem;color:var(--text3);margin-top:10px;line-height:1.5">All-inclusive: hotel, transfers, tests, medications &amp; aftercare.</p>
        </div>
        <div class="td-includes">
          <h5>Every Package Includes</h5>
          <div class="tdi-item"><span class="tdi-icon">✓</span>Pre-operative blood tests &amp; health screening</div>
          <div class="tdi-item"><span class="tdi-icon">✓</span>5-star hotel (6–8 nights)</div>
          <div class="tdi-item"><span class="tdi-icon">✓</span>VIP airport &amp; clinic transfers</div>
          <div class="tdi-item"><span class="tdi-icon">✓</span>1–2 nights hospital stay</div>
          <div class="tdi-item"><span class="tdi-icon">✓</span>Compression garment</div>
          <div class="tdi-item"><span class="tdi-icon">✓</span>All post-op medications</div>
          <div class="tdi-item"><span class="tdi-icon">✓</span>Personal UK coordinator</div>
          <div class="tdi-item"><span class="tdi-icon">✓</span>12-month aftercare support</div>
        </div>
        <!-- Testimonial -->
        <div style="background:#fff;border-radius:var(--radius-xl);padding:20px;border:1px solid var(--border);box-shadow:var(--shadow-sm);margin-top:18px">
          <div style="color:#F59E0B;font-size:.9rem;letter-spacing:2px;margin-bottom:10px">★★★★★</div>
          <p style="font-size:.82rem;color:var(--text2);line-height:1.65;font-style:italic;margin-bottom:14px">"My mummy makeover changed everything. After three children I'd completely lost confidence in my body. Elara's team were with me every step — and the result is genuinely beyond what I hoped for."</p>
          <div style="display:flex;align-items:center;gap:9px">
            <div style="width:36px;height:36px;border-radius:50%;background:var(--grad2);display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:.8rem">KH</div>
            <div><div style="font-weight:700;font-size:.82rem;color:var(--dark)">Karen H., 38</div><div style="font-size:.72rem;color:var(--text3)">Birmingham · Mummy Makeover</div><div style="font-size:.7rem;color:#00B67A;font-weight:600;margin-top:2px">✓ Verified Trustpilot</div></div>
          </div>
        </div>
        <!-- Related -->
        <div style="background:var(--off);border-radius:var(--radius-xl);padding:18px;border:1px solid var(--border);margin-top:18px">
          <div style="font-size:.7rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--text3);margin-bottom:12px">Related Procedures</div>
          <div style="display:flex;flex-direction:column;gap:8px">
            <a href="<?php echo esc_url(elara_page_url('cosmetic-surgery')); ?>" style="display:flex;align-items:center;gap:8px;font-size:.84rem;color:var(--text);padding:8px 10px;border-radius:var(--radius-md);background:#fff;border:1px solid var(--border)">✂️ Tummy Tuck</a>
            <a href="<?php echo esc_url(elara_page_url('cosmetic-surgery')); ?>" style="display:flex;align-items:center;gap:8px;font-size:.84rem;color:var(--text);padding:8px 10px;border-radius:var(--radius-md);background:#fff;border:1px solid var(--border)">👙 Breast Augmentation</a>
            <a href="<?php echo esc_url(elara_page_url('cosmetic-surgery')); ?>" style="display:flex;align-items:center;gap:8px;font-size:.84rem;color:var(--text);padding:8px 10px;border-radius:var(--radius-md);background:#fff;border:1px solid var(--border)">💧 Liposuction</a>
            <a href="<?php echo esc_url(elara_page_url('cosmetic-surgery')); ?>" style="display:flex;align-items:center;gap:8px;font-size:.84rem;color:var(--text);padding:8px 10px;border-radius:var(--radius-md);background:#fff;border:1px solid var(--border)">⬆️ Breast Lift</a>
            <a href="<?php echo esc_url(elara_page_url('cosmetic-surgery')); ?>" style="display:flex;align-items:center;gap:8px;font-size:.84rem;color:var(--text);padding:8px 10px;border-radius:var(--radius-md);background:#fff;border:1px solid var(--border)">🍑 Brazilian Butt Lift</a>
          </div>
        </div>
      </div><!-- /sidebar -->

    </div><!-- /treatment-detail-grid -->
  </div>
</section>

<!-- CTA -->
<section class="cta-banner">
  <div class="container">
    <h2 class="disp-xl" style="color:#fff">Ready to Reclaim Your Body?</h2>
    <p>Speak with one of our specialist body contouring advisors today. Free, confidential and zero obligation.</p>
    <div class="cta-btns">
      <a href="#" class="btn btn-gold btn-xl open-modal">🗓 Book Free Consultation</a>
      <a href="tel:<?php echo esc_attr($phone_clean); ?>" class="btn btn-outline-white btn-xl">📞 <?php echo esc_html($phone); ?></a>
    </div>
  </div>
</section>

<script>
function switchTab(tab, btn) {
  document.querySelectorAll('.mm-panel').forEach(function(p){ p.style.display='none'; });
  document.querySelectorAll('.mm-tab').forEach(function(b){
    b.style.color='var(--text2)';
    b.style.borderBottom='3px solid transparent';
  });
  var panel = document.getElementById('tab-'+tab);
  if(panel) panel.style.display='block';
  btn.style.color='var(--teal)';
  btn.style.borderBottom='3px solid var(--teal)';
}
</script>

<?php get_footer();
