(function(){
'use strict';

// ── SCROLL PROGRESS + HEADER ──
const hdr=document.getElementById('site-header');
const mastheadEl=document.getElementById('masthead');
const topbarEl=document.querySelector('.topbar');
const prog=document.getElementById('scroll-progress');
const btt=document.getElementById('btt');
window.addEventListener('scroll',function(){
  var sy=window.scrollY;
  if(sy>60){
    if(topbarEl)topbarEl.classList.add('hidden');
    if(hdr)hdr.classList.add('scrolled');
    if(mastheadEl)mastheadEl.classList.add('scrolled');
  } else {
    if(topbarEl)topbarEl.classList.remove('hidden');
    if(hdr)hdr.classList.remove('scrolled');
    if(mastheadEl)mastheadEl.classList.remove('scrolled');
  }
  if(btt)btt.classList.toggle('show',sy>400);
  if(prog){var h=document.documentElement.scrollHeight-window.innerHeight;prog.style.width=(h>0?sy/h*100:0)+'%';}
},{passive:true});

// ── MOBILE MENU ──
const hbg=document.getElementById('hbg');
const drawer=document.getElementById('mobDrawer');
const overlay=document.getElementById('mobOverlay');
const mobX=document.getElementById('mobX');
function openMenu(){if(hbg)hbg.classList.add('open');if(drawer)drawer.classList.add('open');if(overlay)overlay.classList.add('open');document.body.style.overflow='hidden';}
function closeMenu(){if(hbg)hbg.classList.remove('open');if(drawer)drawer.classList.remove('open');if(overlay)overlay.classList.remove('open');document.body.style.overflow='';}
if(hbg)hbg.addEventListener('click',openMenu);
if(mobX)mobX.addEventListener('click',closeMenu);
if(overlay)overlay.addEventListener('click',closeMenu);
if(drawer)drawer.querySelectorAll('a').forEach(function(a){a.addEventListener('click',closeMenu);});

// ── MODAL ──
const modalBg=document.getElementById('modalBg');
const modalX=document.getElementById('modalX');
function openModal(){if(modalBg){modalBg.classList.add('open');document.body.style.overflow='hidden';}}
function closeModal(){if(modalBg){modalBg.classList.remove('open');document.body.style.overflow='';}}
document.querySelectorAll('.open-modal').forEach(function(el){el.addEventListener('click',function(e){e.preventDefault();openModal();});});
if(modalX)modalX.addEventListener('click',closeModal);
if(modalBg)modalBg.addEventListener('click',function(e){if(e.target===modalBg)closeModal();});
document.addEventListener('keydown',function(e){if(e.key==='Escape')closeModal();});

// ── CONSULTATION FORM (AJAX) ──
const form=document.getElementById('consultationForm');
if(form){
  form.addEventListener('submit',function(e){
    e.preventDefault();
    const fd=new FormData(form);
    fd.append('action','elara_contact');
    const name=(fd.get('first_name')||'')+' '+(fd.get('last_name')||'');
    fd.append('name',name.trim());
    const btn=form.querySelector('.modal-submit');
    if(btn){btn.textContent='Sending...';btn.disabled=true;}
    fetch(elaraData.ajaxUrl,{method:'POST',body:fd})
      .then(function(r){return r.json();})
      .then(function(data){
        closeModal();
        showToast(data.data?data.data.message:'Thank you! We will be in touch within 2 hours.');
        form.reset();
        if(btn){btn.textContent='Book My Free Consultation →';btn.disabled=false;}
      })
      .catch(function(){
        closeModal();
        showToast('Thank you! We will be in touch within 2 hours.');
        form.reset();
        if(btn){btn.textContent='Book My Free Consultation →';btn.disabled=false;}
      });
  });
}

// ── CONTACT FORM ──
const cf=document.getElementById('contactForm');
if(cf){
  cf.addEventListener('submit',function(e){
    e.preventDefault();
    const fd=new FormData(cf);
    fd.append('action','elara_contact');
    const btn=cf.querySelector('.cf-submit');
    if(btn){btn.textContent='Sending...';btn.disabled=true;}
    fetch(elaraData.ajaxUrl,{method:'POST',body:fd})
      .then(function(r){return r.json();})
      .then(function(){
        showToast('Message sent! We\'ll call you within 2 hours.');
        cf.reset();
        if(btn){btn.textContent='Send My Enquiry →';btn.disabled=false;}
      })
      .catch(function(){
        showToast('Message sent! We\'ll call you within 2 hours.');
        cf.reset();
        if(btn){btn.textContent='Send My Enquiry →';btn.disabled=false;}
      });
  });
}

// ── TOAST ──
function showToast(msg){
  var t=document.getElementById('successToast');
  if(!t)return;
  t.textContent='✓ '+msg;
  t.style.opacity='1';t.style.transform='translateX(-50%) translateY(0)';
  setTimeout(function(){t.style.opacity='0';t.style.transform='translateX(-50%) translateY(20px)';},4500);
}

// ── COUNTERS ──
function runCounter(el){
  var target=+el.dataset.c,dur=2400,start=performance.now();
  (function upd(ts){
    var p=Math.min((ts-start)/dur,1);
    var v=Math.round((1-Math.pow(1-p,4))*target);
    el.textContent=v.toLocaleString();
    if(p<1)requestAnimationFrame(upd);else el.textContent=target.toLocaleString();
  })(performance.now());
}
var cObs=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting&&!e.target.dataset.done){e.target.dataset.done=1;runCounter(e.target);}});},{threshold:.5});
document.querySelectorAll('[data-c]').forEach(function(c){cObs.observe(c);});

// ── SCROLL REVEAL ──
var aObs=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('aos-done');aObs.unobserve(e.target);}});},{threshold:.1,rootMargin:'0px 0px -40px 0px'});
document.querySelectorAll('[data-aos]').forEach(function(el,i){el.style.transitionDelay=(i%5)*60+'ms';aObs.observe(el);});

// ── TESTIMONIAL CAROUSEL ──
var track=document.getElementById('testTrack');
var dots=document.getElementById('tDots');
if(track&&dots){
  var cur=0,autoT;
  var vis=function(){return window.innerWidth<768?1:window.innerWidth<1100?2:3;};
  function mkDots(){dots.innerHTML='';var p=Math.ceil(track.children.length/vis());for(var i=0;i<p;i++){var d=document.createElement('div');d.className='cn-dot'+(i===0?' on':'');(function(idx){d.onclick=function(){go(idx);};})(i);dots.appendChild(d);}}
  function go(n){var p=Math.ceil(track.children.length/vis());cur=(n+p)%p;var w=track.children[0].offsetWidth+22;track.style.transform='translateX(-'+cur*vis()*w+'px)';dots.querySelectorAll('.cn-dot').forEach(function(d,i){d.classList.toggle('on',i===cur);});clearInterval(autoT);autoT=setInterval(function(){go(cur+1);},5500);}
  var tPrev=document.getElementById('tPrev');var tNext=document.getElementById('tNext');
  if(tPrev)tPrev.onclick=function(){go(cur-1);};
  if(tNext)tNext.onclick=function(){go(cur+1);};
  mkDots();autoT=setInterval(function(){go(cur+1);},5500);
  window.addEventListener('resize',function(){mkDots();go(0);});
  var tx=0;
  track.addEventListener('touchstart',function(e){tx=e.touches[0].clientX;},{passive:true});
  track.addEventListener('touchend',function(e){var d=tx-e.changedTouches[0].clientX;if(Math.abs(d)>40)go(d>0?cur+1:cur-1);});
}

// ── FAQ ──
document.querySelectorAll('.faq-item').forEach(function(item){
  var q=item.querySelector('.faq-q');
  if(q)q.addEventListener('click',function(){
    var o=item.classList.contains('open');
    document.querySelectorAll('.faq-item').forEach(function(i){i.classList.remove('open');});
    if(!o)item.classList.add('open');
  });
});

// ── GALLERY FILTERS ──
document.querySelectorAll('.baf[data-f]').forEach(function(b){
  b.addEventListener('click',function(){
    var sec=b.closest('section')||document;
    sec.querySelectorAll('.baf[data-f]').forEach(function(x){x.classList.remove('on');});
    b.classList.add('on');
    var f=b.dataset.f;
    sec.querySelectorAll('[data-cat]').forEach(function(c){c.style.display=(f==='all'||c.dataset.cat===f)?'block':'none';});
  });
});

// ── BLOG FILTERS ──
document.querySelectorAll('.fbtn[onclick*="filterBlog"]').forEach(function(b){
  b.addEventListener('click',function(){
    document.querySelectorAll('.fbtn[onclick*="filterBlog"]').forEach(function(x){x.classList.remove('on');});
    b.classList.add('on');
  });
});

// ── PRICING TECH PILLS ──
document.querySelectorAll('.tech-pill').forEach(function(p){
  p.addEventListener('click',function(){
    document.querySelectorAll('.tech-pill').forEach(function(x){x.classList.remove('on');});
    p.classList.add('on');
  });
});

// ── BTT ──
if(btt)btt.addEventListener('click',function(){window.scrollTo({top:0,behavior:'smooth'});});

// ── COOKIE ──
var cb=document.getElementById('cookieBanner');
if(cb&&!localStorage.getItem('elaraCookie')){setTimeout(function(){cb.classList.add('show');},2200);}
var ca=document.getElementById('cookieAccept');var cd=document.getElementById('cookieDecline');
function closeCookie(){if(cb)cb.classList.remove('show');localStorage.setItem('elaraCookie','1');}
if(ca)ca.addEventListener('click',closeCookie);
if(cd)cd.addEventListener('click',closeCookie);

// ── PARTICLES ──
var pc=document.getElementById('heroParticles');
if(pc){
  for(var i=0;i<20;i++){
    var p=document.createElement('div');
    var s=1+Math.random()*2;
    p.style.cssText='position:absolute;width:'+s+'px;height:'+s+'px;background:rgba(255,255,255,'+(0.15+Math.random()*0.35)+');border-radius:50%;left:'+(Math.random()*100)+'%;animation:float-p '+(10+Math.random()*14)+'s linear '+(Math.random()*-20)+'s infinite;';
    pc.appendChild(p);
  }
  var ps=document.createElement('style');
  ps.textContent='@keyframes float-p{0%{transform:translateY(100vh);opacity:0}10%{opacity:1}90%{opacity:.3}100%{transform:translateY(-100px);opacity:0}}';
  document.head.appendChild(ps);
}

// ── EXIT INTENT POPUP ──
var exitShown=sessionStorage.getItem('elaraExit');
document.addEventListener('mouseleave',function(e){
  if(e.clientY<5&&!exitShown){
    exitShown=true;sessionStorage.setItem('elaraExit','1');
    setTimeout(openModal,500);
  }
});

})();
