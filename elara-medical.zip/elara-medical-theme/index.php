<?php // index.php - fallback template
get_header(); ?>
<main style="padding:160px 0 80px;min-height:60vh">
  <div class="container">
    <?php if(have_posts()):while(have_posts()):the_post(); ?>
    <article>
      <h1 style="font-family:var(--font-display);font-size:2.5rem;color:var(--dark);margin-bottom:20px"><?php the_title(); ?></h1>
      <div style="color:var(--text2);line-height:1.8"><?php the_content(); ?></div>
    </article>
    <?php endwhile; endif; ?>
  </div>
</main>
<?php get_footer();
