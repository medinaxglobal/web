<?php /* page.php */ get_header(); ?>
<main style="padding:160px 0 80px;min-height:60vh">
  <div class="container" style="max-width:860px">
    <?php if(have_posts()):while(have_posts()):the_post(); ?>
    <h1 style="font-family:var(--font-display);font-size:clamp(2rem,4vw,3rem);color:var(--dark);margin-bottom:24px"><?php the_title(); ?></h1>
    <div class="wp-content" style="color:var(--text2);line-height:1.8;font-size:.97rem"><?php the_content(); ?></div>
    <?php endwhile;endif; ?>
  </div>
</main>
<?php get_footer();
