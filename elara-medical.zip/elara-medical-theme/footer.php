<?php
$phone    = elara_phone();
$email    = elara_email();
$whatsapp = elara_whatsapp();
?>
<!-- FOOTER -->
<footer class="footer">
  <div class="container">
    <div class="footer-grid">
      <div class="f-brand">
        <div class="flogo">
          <div class="logo-gem" style="width:30px;height:30px;border-radius:9px"><svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M12 2L8 8H2L6 13L4 20L12 16L20 20L18 13L22 8H16L12 2Z" fill="white"/></svg></div>
          <?php bloginfo('name'); ?>
        </div>
        <p>The UK's most trusted gateway to world-class cosmetic surgery, hair restoration, dental care, weight loss surgery and eye treatments in Istanbul. Trusted by over 18,000 patients from across Britain.</p>
        <div class="f-badges">
          <span class="fb">ISO 9001</span><span class="fb">JCI Partner</span><span class="fb">ICO Reg</span><span class="fb">UK Ltd Co.</span><span class="fb">Trustpilot 4.9★</span>
        </div>
        <div class="f-socials">
          <a href="#" class="fsoc" aria-label="Facebook"><svg width="14" height="14" fill="currentColor" viewBox="0 0 24 24"><path d="M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z"/></svg></a>
          <a href="#" class="fsoc" aria-label="Instagram"><svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="2" y="2" width="20" height="20" rx="5"/><path d="M16 11.37A4 4 0 1112.63 8 4 4 0 0116 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg></a>
          <a href="#" class="fsoc" aria-label="YouTube"><svg width="14" height="14" fill="currentColor" viewBox="0 0 24 24"><path d="M22.54 6.42a2.78 2.78 0 00-1.95-1.96C18.88 4 12 4 12 4s-6.88 0-8.59.46a2.78 2.78 0 00-1.95 1.96A29 29 0 001 12a29 29 0 00.46 5.58A2.78 2.78 0 003.41 19.6C5.12 20 12 20 12 20s6.88 0 8.59-.46a2.78 2.78 0 001.95-1.95A29 29 0 0023 12a29 29 0 00-.46-5.58z"/><polygon fill="white" points="9.75 15.02 15.5 12 9.75 8.98"/></svg></a>
        </div>
      </div>
      <div class="f-col">
        <h5>Treatments</h5>
        <div class="f-links">
          <a href="<?php echo esc_url(elara_page_url('hair-transplant')); ?>">Hair Transplant</a>
          <a href="<?php echo esc_url(elara_page_url('cosmetic-surgery')); ?>">Rhinoplasty</a>
          <a href="<?php echo esc_url(elara_page_url('cosmetic-surgery')); ?>">Breast Surgery</a>
          <a href="<?php echo esc_url(elara_page_url('cosmetic-surgery')); ?>">Body Contouring</a>
          <a href="<?php echo esc_url(elara_page_url('mummy-makeover')); ?>">Mummy Makeover</a>
          <a href="<?php echo esc_url(elara_page_url('dental-treatments')); ?>">Dental Implants</a>
          <a href="<?php echo esc_url(elara_page_url('dental-treatments')); ?>">Hollywood Smile</a>
          <a href="<?php echo esc_url(elara_page_url('weight-loss')); ?>">Weight Loss Surgery</a>
          <a href="<?php echo esc_url(elara_page_url('eye-treatments')); ?>">Eye Treatments</a>
        </div>
      </div>
      <div class="f-col">
        <h5>Company</h5>
        <div class="f-links">
          <a href="<?php echo esc_url(elara_page_url('about-us')); ?>">About Elara Medical</a>
          <a href="<?php echo esc_url(elara_page_url('about-us')); ?>">Our Surgeons</a>
          <a href="<?php echo esc_url(elara_page_url('locations')); ?>">Locations</a>
          <a href="<?php echo esc_url(elara_page_url('patient-stories')); ?>">Patient Stories</a>
          <a href="<?php echo esc_url(elara_page_url('patient-stories')); ?>">Before &amp; After Gallery</a>
          <a href="<?php echo esc_url(elara_page_url('pricing')); ?>">Pricing &amp; Packages</a>
          <a href="<?php echo esc_url(elara_page_url('cost-finance')); ?>">Cost &amp; Finance</a>
          <a href="<?php echo esc_url(elara_page_url('blog')); ?>">Blog &amp; Guides</a>
          <a href="<?php echo esc_url(elara_page_url('faq')); ?>">FAQ</a>
        </div>
      </div>
      <div class="f-col">
        <h5>Contact</h5>
        <div class="fcontact-item">
          <svg class="fci-icon" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81a19.79 19.79 0 01-3.07-8.67A2 2 0 012 3h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.09 11a16 16 0 006.72 6.72l1.36-1.36a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 18.92z"/></svg>
          <div><a href="tel:<?php echo esc_attr(str_replace(' ','',$phone)); ?>"><?php echo esc_html($phone); ?></a><br><span style="font-size:.72rem">Mon–Sat · 9am–7pm</span></div>
        </div>
        <div class="fcontact-item">
          <svg class="fci-icon" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
          <a href="mailto:<?php echo esc_attr($email); ?>"><?php echo esc_html($email); ?></a>
        </div>
        <div class="fcontact-item">
          <svg class="fci-icon" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
          <span>Suite 14, 22 Bishopsgate<br>London, EC2N 4BQ</span>
        </div>
        <a href="#" class="btn btn-primary open-modal" style="margin-top:14px;font-size:.82rem;display:inline-flex">Book Free Consultation</a>
      </div>
    </div>
    <div class="footer-bot">
      <p class="fb-copy">© <?php echo date('Y'); ?> <?php bloginfo('name'); ?> Ltd. Registered in England &amp; Wales. All rights reserved.</p>
      <div class="fb-links">
        <a href="<?php echo esc_url(get_privacy_policy_url()); ?>">Privacy Policy</a>
        <a href="#">Terms &amp; Conditions</a>
        <a href="#">Cookies</a>
        <a href="#">Accessibility</a>
        <a href="#">Medical Disclaimer</a>
      </div>
    </div>
    <div class="footer-disclaimer">
      <?php bloginfo('name'); ?> Ltd facilitates access to independent medical practitioners and accredited clinics. We do not provide medical advice. All procedures carry inherent risks. Please read our full medical disclaimer before proceeding. Results may vary.
    </div>
  </div>
</footer>

<!-- WHATSAPP BUTTON -->
<div class="wa-btn">
  <div class="wa-ring"></div>
  <a href="https://wa.me/<?php echo esc_attr($whatsapp); ?>?text=Hello%2C%20I'd%20like%20to%20enquire%20about%20a%20treatment" target="_blank" rel="noopener" aria-label="WhatsApp Elara Medical">
    <svg viewBox="0 0 24 24" fill="white"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347zM12 0C5.373 0 0 5.373 0 12c0 2.126.555 4.126 1.527 5.865L.057 23.143l5.42-1.424A11.93 11.93 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 22c-1.893 0-3.661-.516-5.172-1.41l-.371-.22-3.217.845.86-3.135-.243-.395A9.956 9.956 0 012 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10z"/></svg>
    <span>WhatsApp</span>
  </a>
</div>

<!-- BACK TO TOP -->
<div class="btt" id="btt" aria-label="Back to top">
  <svg width="18" height="18" fill="none" stroke="white" stroke-width="2.5" viewBox="0 0 24 24"><polyline points="18 15 12 9 6 15"/></svg>
</div>

<!-- CONSULTATION MODAL -->
<div class="modal-bg" id="modalBg">
  <div class="modal">
    <div class="modal-left">
      <div class="ml-content">
        <h3>Join 18,000+ Patients Who Chose Elara Medical</h3>
        <p>Book your free consultation today and receive a personalised treatment plan within 24 hours.</p>
      </div>
      <div class="ml-proof">
        <div class="ml-tp"><span class="tp-s">★★★★★</span><span>4.9 / 5 on Trustpilot</span></div>
        <div class="ml-feat"><svg width="13" height="13" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/></svg>100% Free · Zero obligation</div>
        <div class="ml-feat"><svg width="13" height="13" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/></svg>Speak to a specialist, not a salesperson</div>
        <div class="ml-feat"><svg width="13" height="13" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/></svg>Personalised plan in 24 hours</div>
      </div>
    </div>
    <div class="modal-right">
      <div class="modal-x" id="modalX"><svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M18 6L6 18M6 6l12 12"/></svg></div>
      <h4>Book Your Free Consultation</h4>
      <p style="font-size:.84rem;color:var(--text3);margin-bottom:22px">Takes 2 minutes. Zero obligation. Expert advice guaranteed.</p>
      <form id="consultationForm">
        <?php wp_nonce_field('elara_contact','elara_nonce'); ?>
        <div class="mfg-row">
          <div class="mfg"><label>First Name *</label><input type="text" name="first_name" placeholder="First name" required autocomplete="given-name"></div>
          <div class="mfg"><label>Last Name *</label><input type="text" name="last_name" placeholder="Last name" required autocomplete="family-name"></div>
        </div>
        <div class="mfg"><label>Email Address *</label><input type="email" name="email" placeholder="your@email.com" required autocomplete="email"></div>
        <div class="mfg"><label>Phone Number *</label><input type="tel" name="phone" placeholder="+44 7000 000000" required autocomplete="tel"></div>
        <div class="mfg">
          <label>Treatment of Interest</label>
          <select name="treatment">
            <option value="">Select a treatment...</option>
            <option>Hair Transplant (FUE)</option>
            <option>Hair Transplant (DHI)</option>
            <option>Rhinoplasty (Nose Job)</option>
            <option>Breast Augmentation</option>
            <option>Body Contouring / Liposuction</option>
            <option>Tummy Tuck</option>
            <option>Dental Implants</option>
            <option>Hollywood Smile / Veneers</option>
            <option>Weight Loss Surgery</option>
            <option>Laser Eye Surgery</option>
            <option>Not sure yet</option>
          </select>
        </div>
        <button type="submit" class="modal-submit">Book My Free Consultation →</button>
      </form>
      <p class="modal-disc">We never share your details. <a href="<?php echo esc_url(get_privacy_policy_url()); ?>" style="color:var(--teal)">Privacy Policy</a>.</p>
    </div>
  </div>
</div>

<!-- COOKIE BANNER -->
<div class="cookie-banner" id="cookieBanner">
  <p class="cookie-text">We use cookies to enhance your experience and analyse site performance. By continuing to browse, you agree to our <a href="#">Cookie Policy</a> and <a href="<?php echo esc_url(get_privacy_policy_url()); ?>">Privacy Policy</a>.</p>
  <div class="cookie-btns">
    <button class="btn btn-outline-white" id="cookieDecline" style="padding:9px 18px;font-size:.82rem">Decline</button>
    <button class="btn btn-gold" id="cookieAccept" style="padding:9px 18px;font-size:.82rem">Accept All</button>
  </div>
</div>

<!-- SUCCESS TOAST -->
<div id="successToast" style="position:fixed;bottom:80px;left:50%;transform:translateX(-50%) translateY(20px);background:var(--teal);color:#fff;padding:14px 28px;border-radius:9999px;box-shadow:0 8px 32px rgba(0,0,0,.2);font-weight:600;font-size:.92rem;z-index:10001;opacity:0;transition:all .4s;pointer-events:none;white-space:nowrap">
  ✓ Message sent! We'll call you within 2 hours.
</div>

<?php wp_footer(); ?>
</body>
</html>
