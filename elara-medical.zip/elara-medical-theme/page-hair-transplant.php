<?php /* Template Name: Hair Transplant */ get_header(); ?>
<div class="page-hero"><div class="container"><div>
<div class="ph-breadcrumb"><a href="<?php echo home_url('/'); ?>">Home</a><span>›</span><span>Hair Transplant</span></div>
<div class="ph-tags"><span class="badge badge-white">FUE</span><span class="badge badge-white">DHI</span><span class="badge badge-white">Sapphire FUE</span></div>
<h1 class="disp-xl ph-h1">Hair Transplant in Istanbul — <em style="font-style:italic">Natural Results. Permanent Confidence.</em></h1>
<p class="ph-sub">Restore your hairline permanently with Istanbul's most advanced techniques — at up to 75% less than UK clinic prices.</p>
<div class="ph-ctas"><a href="#" class="btn btn-gold btn-lg open-modal">Free Hair Assessment</a><a href="<?php echo esc_url(elara_page_url('patient-stories')); ?>" class="btn btn-outline-white btn-lg">View Results Gallery</a></div>
</div><div class="ph-right"><h4>Quick Facts</h4><div class="quick-list"><div class="ql-item"><span class="ql-icon">💷</span>From £1,499 all-inclusive</div><div class="ql-item"><span class="ql-icon">✈</span>3–5 night Istanbul stay</div><div class="ql-item"><span class="ql-icon">🕒</span>6–8 hour procedure</div><div class="ql-item"><span class="ql-icon">📅</span>Full results at 12–14 months</div><div class="ql-item"><span class="ql-icon">💊</span>Medications included</div><div class="ql-item"><span class="ql-icon">📞</span>UK aftercare included</div></div></div>
</div></div></div>
<section class="sec"><div class="container"><div class="treatment-detail-grid">
<div class="treatment-content">
<h2>What Is a Hair Transplant?</h2>
<p>A hair transplant moves healthy follicles from a donor area to thinning or bald zones. Modern techniques deliver permanent, natural-looking results indistinguishable from untouched hair.</p>
<p>Istanbul performs more hair transplants per year than any other city globally — giving our surgeons a level of expertise that far surpasses lower-volume UK clinics.</p>
<h2>Which Technique Is Right for You?</h2>
<div class="tech-comparison">
<div class="tech-card"><h4>FUE</h4><p>Individual follicles extracted with a micro-punch and implanted precisely. The global gold standard.</p><span class="tech-tag">Best for: General hair loss</span></div>
<div class="tech-card featured-tech"><h4>DHI ★ Recommended</h4><p>Simultaneous extraction and implantation via Choi pen — superior density and faster healing.</p><span class="tech-tag">Best for: Crown &amp; frontal density</span></div>
<div class="tech-card"><h4>Sapphire FUE</h4><p>Sapphire-tipped blades create finer channels, faster healing — ideal for sensitive scalps.</p><span class="tech-tag">Best for: Sensitive scalps</span></div>
</div>
<h2>Expected Results Timeline</h2>
<ul><li>Months 1–3: Initial shedding phase (normal — follicles are settling)</li><li>Months 3–6: Early regrowth becomes visible</li><li>Months 6–10: Significant density improvement</li><li>Months 10–14: Full results — complete, natural, permanent density</li></ul>
<h2>Pricing vs UK Clinics</h2>
<div style="overflow:hidden;border-radius:var(--radius-xl);margin:20px 0">
<table class="comp-table" style="width:100%"><thead><tr><th>Procedure</th><th>UK Average</th><th style="background:var(--teal)">Elara Medical</th><th>You Save</th></tr></thead>
<tbody>
<tr><td>FUE (2,000–3,000 grafts)</td><td>£7,000–£12,000</td><td class="comp-highlight"><strong style="color:var(--teal)">From £1,499</strong></td><td>Up to <strong>£10,500</strong></td></tr>
<tr><td>DHI (3,000–4,000 grafts)</td><td>£9,000–£15,000</td><td class="comp-highlight"><strong style="color:var(--teal)">From £1,899</strong></td><td>Up to <strong>£13,100</strong></td></tr>
<tr><td>Sapphire FUE</td><td>£8,000–£13,000</td><td class="comp-highlight"><strong style="color:var(--teal)">From £1,699</strong></td><td>Up to <strong>£11,300</strong></td></tr>
<tr><td>Beard Transplant</td><td>£4,000–£7,000</td><td class="comp-highlight"><strong style="color:var(--teal)">From £1,299</strong></td><td>Up to <strong>£5,700</strong></td></tr>
</tbody></table></div>
</div>
<div class="td-sidebar">
<div class="td-cta-card"><h4>Get Your Free Assessment</h4><p>Find out exactly how many grafts you need and which technique suits your hair type.</p><a href="#" class="btn btn-gold open-modal" style="width:100%;justify-content:center;display:flex;margin-bottom:10px">Book Free Assessment</a><a href="tel:<?php echo esc_attr(str_replace(' ','',elara_phone())); ?>" class="btn btn-outline-white" style="width:100%;justify-content:center;display:flex">📞 <?php echo esc_html(elara_phone()); ?></a></div>
<div class="td-price-card"><h5>Procedure Pricing</h5><div class="tdp-item"><span class="tdp-name">FUE Hair Transplant</span><span class="tdp-price">From £1,499</span></div><div class="tdp-item"><span class="tdp-name">DHI Hair Transplant</span><span class="tdp-price">From £1,899</span></div><div class="tdp-item"><span class="tdp-name">Sapphire FUE</span><span class="tdp-price">From £1,699</span></div><div class="tdp-item"><span class="tdp-name">Beard Transplant</span><span class="tdp-price">From £1,299</span></div><div class="tdp-item"><span class="tdp-name">Female Hair Transplant</span><span class="tdp-price">From £1,499</span></div></div>
<div class="td-includes"><h5>Every Package Includes</h5><div class="tdi-item"><span class="tdi-icon">✓</span>Pre-op medical tests</div><div class="tdi-item"><span class="tdi-icon">✓</span>4-star hotel (3–5 nights)</div><div class="tdi-item"><span class="tdi-icon">✓</span>VIP airport transfers</div><div class="tdi-item"><span class="tdi-icon">✓</span>Personal coordinator</div><div class="tdi-item"><span class="tdi-icon">✓</span>Post-op care kit</div><div class="tdi-item"><span class="tdi-icon">✓</span>12-month follow-up</div><div class="tdi-item"><span class="tdi-icon">✓</span>UK aftercare team</div></div>
</div>
</div></div></section>
<section class="cta-banner"><div class="container"><h2 class="disp-xl" style="color:#fff">Ready to Restore Your Hairline?</h2><p style="color:rgba(255,255,255,.65);margin-bottom:32px">Get your free personalised hair assessment today.</p><div class="cta-btns"><a href="#" class="btn btn-gold btn-xl open-modal">Get Free Hair Assessment</a></div></div></section>
<?php get_footer();
