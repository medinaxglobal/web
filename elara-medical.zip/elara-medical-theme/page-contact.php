<?php /* Template Name: Contact */ get_header(); ?>
<div class="page-hero"><div class="container"><div>
<div class="ph-breadcrumb"><a href="<?php echo home_url('/'); ?>">Home</a><span>›</span><span>Contact</span></div>
<h1 class="disp-xl ph-h1">Get In Touch — <em style="font-style:italic">We're Ready to Help</em></h1>
<p class="ph-sub">Our UK-based team is available 7 days a week. No pressure, no obligation — only honest guidance from our specialist advisors.</p>
</div></div></div>
<section class="sec"><div class="container">
<div class="contact-grid">
<div>
<div class="contact-info-card" data-aos="left">
<div class="ci-title">How to Reach Us</div>
<div class="ci-item"><div class="ci-icon"><svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81a19.79 19.79 0 01-3.07-8.67A2 2 0 012 3h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.09 11a16 16 0 006.72 6.72l1.36-1.36a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 18.92z"/></svg></div><div class="ci-txt"><strong>Call Us</strong><a href="tel:<?php echo esc_attr(str_replace(' ','',elara_phone())); ?>"><?php echo esc_html(elara_phone()); ?></a><br><span>Mon–Sat · 9am–7pm</span></div></div>
<div class="ci-item"><div class="ci-icon"><svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg></div><div class="ci-txt"><strong>Email Us</strong><a href="mailto:<?php echo esc_attr(elara_email()); ?>"><?php echo esc_html(elara_email()); ?></a><br><span>Response within 4 hours</span></div></div>
<div class="ci-item"><div class="ci-icon">💬</div><div class="ci-txt"><strong>WhatsApp</strong><a href="https://wa.me/<?php echo esc_attr(elara_whatsapp()); ?>">+<?php echo esc_html(elara_whatsapp()); ?></a><br><span>Available 7 days a week</span></div></div>
<div class="ci-item"><div class="ci-icon"><svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg></div><div class="ci-txt"><strong>UK Office</strong><span>Suite 14, 22 Bishopsgate<br>London, EC2N 4BQ</span></div></div>
<div class="ci-item"><div class="ci-icon">🌍</div><div class="ci-txt"><strong>Istanbul Patient Lounge</strong><span>Teşvikiye, Şişli<br>Istanbul, Turkey</span></div></div>
</div>
</div>
<div class="contact-form" data-aos="right">
<div class="cf-title">Send Us a Message</div>
<div class="cf-sub">Fill in the form and we'll call you back within 2 hours during business hours.</div>
<form id="contactForm">
<?php wp_nonce_field('elara_contact','elara_nonce'); ?>
<div class="cf-grid">
<div class="cf-group"><label>First Name *</label><input type="text" name="first_name" placeholder="Your first name" required autocomplete="given-name"></div>
<div class="cf-group"><label>Last Name *</label><input type="text" name="last_name" placeholder="Your last name" required autocomplete="family-name"></div>
<div class="cf-group"><label>Email Address *</label><input type="email" name="email" placeholder="your@email.com" required autocomplete="email"></div>
<div class="cf-group"><label>Phone Number *</label><input type="tel" name="phone" placeholder="+44 7000 000000" required autocomplete="tel"></div>
<div class="cf-group cf-full"><label>Treatment of Interest</label><select name="treatment"><option value="">Select a treatment...</option><option>Hair Transplant (FUE)</option><option>Hair Transplant (DHI)</option><option>Rhinoplasty</option><option>Breast Augmentation</option><option>Body Contouring</option><option>Tummy Tuck</option><option>Dental Implants</option><option>Hollywood Smile</option><option>Weight Loss Surgery</option><option>Laser Eye Surgery</option><option>Not sure yet</option></select></div>
<div class="cf-group cf-full"><label>Your Message</label><textarea name="message" rows="4" placeholder="Tell us about your goals or any questions you have..."></textarea></div>
</div>
<button type="submit" class="cf-submit">Send My Enquiry →</button>
<p style="font-size:.72rem;color:var(--text3);margin-top:10px;text-align:center">We never share your details. <a href="<?php echo esc_url(get_privacy_policy_url()); ?>" style="color:var(--teal)">Privacy Policy</a>.</p>
</form>
</div>
</div>
</div></section>
<?php get_footer();
