<?php /* Template Name: Weight Loss Surgery */ get_header(); ?>
<div class="page-hero"><div class="container"><div>
<div class="ph-breadcrumb"><a href="<?php echo home_url('/'); ?>">Home</a><span>›</span><span>Weight Loss Surgery</span></div>
<div class="ph-tags"><span class="badge badge-white">Gastric Sleeve</span><span class="badge badge-white">Bypass</span><span class="badge badge-white">Balloon</span></div>
<h1 class="disp-xl ph-h1">Weight Loss Surgery in Istanbul — <em style="font-style:italic">Life-Changing Results, Fraction of UK Costs.</em></h1>
<p class="ph-sub">Clinically proven bariatric procedures performed by Istanbul's most experienced weight loss surgeons. All-inclusive packages from £2,800 with full UK aftercare.</p>
<div class="ph-ctas"><a href="#" class="btn btn-gold btn-lg open-modal">Free Bariatric Consultation</a><a href="<?php echo esc_url(elara_page_url('pricing')); ?>" class="btn btn-outline-white btn-lg">View Pricing</a></div>
</div><div class="ph-right"><h4>Key Facts</h4><div class="quick-list"><div class="ql-item"><span class="ql-icon">💷</span>From £2,800 all-inclusive</div><div class="ql-item"><span class="ql-icon">✈</span>3–5 night Istanbul stay</div><div class="ql-item"><span class="ql-icon">⚖️</span>Average 60–80% excess weight loss</div><div class="ql-item"><span class="ql-icon">🏥</span>JCI-accredited hospital</div><div class="ql-item"><span class="ql-icon">📞</span>UK dietitian aftercare included</div></div></div>
</div></div></div>
<section class="sec"><div class="container">
<div class="sh center" data-aos="up" style="margin-bottom:52px"><span class="label label-teal">Bariatric Procedures</span><h2 class="disp-xl">Choose the Right Procedure <em style="font-style:italic">for Your Goals</em></h2></div>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:28px">
<div class="card" data-aos="up" style="padding:36px;border:2px solid var(--teal)">
<h3 style="font-family:var(--font-display);font-size:1.5rem;font-weight:700;color:var(--dark);margin-bottom:12px">⚡ Gastric Sleeve <span style="font-size:.7rem;background:var(--teal);color:#fff;padding:3px 10px;border-radius:var(--radius-pill);font-family:var(--font-body);letter-spacing:.06em">MOST POPULAR</span></h3>
<p style="color:var(--text2);line-height:1.75;margin-bottom:20px;font-size:.93rem">75–80% of the stomach is removed, creating a sleeve-shaped pouch that dramatically reduces appetite. No foreign implants, no intestinal bypass.</p>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:20px">
<div style="background:var(--teal-l);border-radius:var(--radius-lg);padding:12px;text-align:center"><div style="font-weight:800;color:var(--teal);font-size:1.1rem">60–70%</div><div style="font-size:.74rem;color:var(--text3)">Excess weight lost</div></div>
<div style="background:var(--teal-l);border-radius:var(--radius-lg);padding:12px;text-align:center"><div style="font-weight:800;color:var(--teal);font-size:1.1rem">2–3 nights</div><div style="font-size:.74rem;color:var(--text3)">Hospital stay</div></div>
</div>
<div style="font-size:1.1rem;font-weight:800;color:var(--teal)">From £2,800 all-inclusive</div>
</div>
<div class="card" data-aos="up" style="padding:36px">
<h3 style="font-family:var(--font-display);font-size:1.5rem;font-weight:700;color:var(--dark);margin-bottom:12px">🔄 Gastric Bypass (Roux-en-Y)</h3>
<p style="color:var(--text2);line-height:1.75;margin-bottom:20px;font-size:.93rem">Creates a small stomach pouch and reroutes the small intestine — the gold standard for patients with BMI over 45 or obesity-related diabetes.</p>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:20px">
<div style="background:var(--off);border-radius:var(--radius-lg);padding:12px;text-align:center"><div style="font-weight:800;color:var(--dark);font-size:1.1rem">70–80%</div><div style="font-size:.74rem;color:var(--text3)">Excess weight lost</div></div>
<div style="background:var(--off);border-radius:var(--radius-lg);padding:12px;text-align:center"><div style="font-weight:800;color:var(--dark);font-size:1.1rem">3–4 nights</div><div style="font-size:.74rem;color:var(--text3)">Hospital stay</div></div>
</div>
<div style="font-size:1.1rem;font-weight:800;color:var(--teal)">From £3,400 all-inclusive</div>
</div>
<div class="card" data-aos="up" style="padding:36px">
<h3 style="font-family:var(--font-display);font-size:1.5rem;font-weight:700;color:var(--dark);margin-bottom:12px">🎈 Gastric Balloon (Non-Surgical)</h3>
<p style="color:var(--text2);line-height:1.75;margin-bottom:20px;font-size:.93rem">A silicone balloon placed inside the stomach via endoscopy and inflated with saline. No surgery, no incisions. Temporary 6–12 month procedure.</p>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:20px">
<div style="background:var(--off);border-radius:var(--radius-lg);padding:12px;text-align:center"><div style="font-weight:800;color:var(--dark);font-size:1.1rem">20–30%</div><div style="font-size:.74rem;color:var(--text3)">Excess weight lost</div></div>
<div style="background:var(--off);border-radius:var(--radius-lg);padding:12px;text-align:center"><div style="font-weight:800;color:var(--dark);font-size:1.1rem">Day case</div><div style="font-size:.74rem;color:var(--text3)">No hospital stay</div></div>
</div>
<div style="font-size:1.1rem;font-weight:800;color:var(--teal)">From £1,400 all-inclusive</div>
</div>
<div class="card" data-aos="up" style="padding:36px">
<h3 style="font-family:var(--font-display);font-size:1.5rem;font-weight:700;color:var(--dark);margin-bottom:12px">💊 Gastric Band (Lap-Band)</h3>
<p style="color:var(--text2);line-height:1.75;margin-bottom:20px;font-size:.93rem">An adjustable silicone band around the upper stomach restricts food intake. Fully reversible and adjustable without further surgery.</p>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:20px">
<div style="background:var(--off);border-radius:var(--radius-lg);padding:12px;text-align:center"><div style="font-weight:800;color:var(--dark);font-size:1.1rem">40–50%</div><div style="font-size:.74rem;color:var(--text3)">Excess weight lost</div></div>
<div style="background:var(--off);border-radius:var(--radius-lg);padding:12px;text-align:center"><div style="font-weight:800;color:var(--dark);font-size:1.1rem">1–2 nights</div><div style="font-size:.74rem;color:var(--text3)">Hospital stay</div></div>
</div>
<div style="font-size:1.1rem;font-weight:800;color:var(--teal)">From £2,400 all-inclusive</div>
</div>
</div>
</div></section>
<section class="cta-banner"><div class="container"><h2 class="disp-xl" style="color:#fff">Begin Your Weight Loss Journey</h2><p style="color:rgba(255,255,255,.65);margin-bottom:32px">Free consultation — no pressure, complete transparency.</p><div class="cta-btns"><a href="#" class="btn btn-gold btn-xl open-modal">Book Free Bariatric Consultation</a></div></div></section>
<?php get_footer();
