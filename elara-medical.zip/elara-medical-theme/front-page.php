<?php
/**
 * Template Name: Home Page
 * Front page template for Elara Medical
 */
get_header();
?>

<!-- HERO -->
<section class="hero">
  <div class="hero-mesh"></div>
  <div class="hero-grid-lines"></div>
  <div class="hero-particles" id="heroParticles"></div>
  <div class="hero-orb" style="width:500px;height:500px;background:radial-gradient(circle,rgba(11,107,150,.25),transparent);top:-100px;right:-100px;animation-duration:8s"></div>
  <div class="hero-orb" style="width:380px;height:380px;background:radial-gradient(circle,rgba(200,152,42,.15),transparent);bottom:-80px;left:-80px;animation-duration:11s;animation-delay:-4s"></div>
  <div class="hero-content">
    <div class="hero-left">
      <div class="hero-badge-row" data-aos="fade">
        <div class="hero-badge"><span class="hero-badge-dot"></span>Now Accepting New Patients</div>
        <div class="hero-badge">🇬🇧 UK-Based Support Team</div>
      </div>
      <h1 class="disp-hero" data-aos="up">
        <span class="line1">Experience the</span>
        <span class="line2">Art of <span class="accent">Transformation</span></span>
      </h1>
      <p class="hero-sub" data-aos="up">Premium hair transplants, cosmetic surgery, dental care, weight loss and eye treatments in Istanbul's finest clinics — at a fraction of UK prices. Trusted by over 18,000 patients from across Britain.</p>
      <div class="hero-ctas" data-aos="up">
        <a href="#" class="btn btn-gold btn-xl open-modal">
          <svg width="17" height="17" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
          Book Free Consultation
        </a>
        <a href="<?php echo esc_url(elara_page_url('patient-stories')); ?>" class="btn btn-outline-white btn-xl">
          <svg width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="10 15 15 12 10 9"/></svg>
          Watch Patient Stories
        </a>
      </div>
      <div class="hero-trust-row" data-aos="fade">
        <div class="htrust"><span>🏆</span> ISO 9001</div>
        <span class="htrust-sep">·</span>
        <div class="htrust"><span>✓</span> JCI Accredited</div>
        <span class="htrust-sep">·</span>
        <div class="htrust"><span>⭐</span> 4.9 Trustpilot</div>
        <span class="htrust-sep">·</span>
        <div class="htrust"><span>✈</span> All-Inclusive</div>
      </div>
    </div>
    <div class="hero-right" data-aos="right">
      <div class="hero-float1">
        <div class="hf-icon"><svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/></svg></div>
        <div class="hf-text"><strong>18,000+ Patients</strong><span>Successfully Transformed</span></div>
      </div>
      <div class="hero-card-main">
        <div class="hero-card-main-img"><img src="https://images.unsplash.com/photo-1551190822-a9333d879b1f?w=600&q=80" alt="Elara Medical premium consultation suite" loading="eager"></div>
        <div class="hero-stats-row">
          <div class="hero-mini-stat"><span class="hms-num" data-c="98">0</span><span style="color:var(--gold);font-size:1rem;font-weight:700">%</span><span class="hms-label">Satisfaction</span></div>
          <div class="hero-mini-stat"><span class="hms-num" data-c="12">0</span><span style="color:var(--gold);font-size:1rem;font-weight:700">+</span><span class="hms-label">Years</span></div>
          <div class="hero-mini-stat"><span class="hms-num" data-c="4">0</span><span style="color:var(--gold);font-size:1rem;font-weight:700">.9★</span><span class="hms-label">Rating</span></div>
        </div>
      </div>
      <div class="hero-float2">
        <div><div class="hf2-stars">★★★★★</div><div class="hf2-sub">Trustpilot</div></div>
        <div><div class="hf2-text">4.9 / 5 Rating</div><div class="hf2-sub">3,200+ verified reviews</div></div>
      </div>
    </div>
  </div>
  <div class="hero-scroll"><div class="scroll-track"></div><span>Scroll</span></div>
</section>

<!-- MEDIA BAR -->
<div class="media-bar">
  <div class="container">
    <span class="mb-sep">As Featured In</span>
    <div class="mb-logos">
      <span class="mb-logo">The Guardian</span>
      <span class="mb-logo">Daily Mail</span>
      <span class="mb-logo">Cosmopolitan</span>
      <span class="mb-logo">The Telegraph</span>
      <span class="mb-logo">BBC Health</span>
      <div class="tp-widget"><span class="tp-s">★★★★★</span><span class="tp-score">4.9 Trustpilot</span></div>
    </div>
  </div>
</div>

<!-- STATS -->
<section class="stats-sec">
  <div class="container">
    <div class="stats-grid">
      <div class="stat-item" data-aos="up"><span class="stat-icon">💎</span><div class="stat-wrap"><span class="stat-n" data-c="18000">0</span><span class="stat-s">+</span></div><div class="stat-l">Patients Transformed</div><div class="stat-d">Across all specialties</div></div>
      <div class="stat-item" data-aos="up"><span class="stat-icon">⭐</span><div class="stat-wrap"><span class="stat-n" data-c="98">0</span><span class="stat-s">%</span></div><div class="stat-l">Patient Satisfaction</div><div class="stat-d">Post-procedure survey</div></div>
      <div class="stat-item" data-aos="up"><span class="stat-icon">🏥</span><div class="stat-wrap"><span class="stat-n" data-c="12">0</span><span class="stat-s">+</span></div><div class="stat-l">Years of Excellence</div><div class="stat-d">Facilitating transformations</div></div>
      <div class="stat-item" data-aos="up"><span class="stat-icon">💷</span><div class="stat-wrap"><span class="stat-s" style="color:var(--gold)">£</span><span class="stat-n" data-c="4200">0</span></div><div class="stat-l">Average Patient Saving</div><div class="stat-d">Compared to UK pricing</div></div>
    </div>
  </div>
</section>

<!-- WHY CHOOSE US -->
<section class="sec bg-off">
  <div class="container">
    <div class="about-grid">
      <div style="position:relative" data-aos="left">
        <div class="about-img-main"><img src="https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=700&q=80" alt="Elara Medical patient consultation" loading="lazy"></div>
        <div class="about-badge2"><span class="ab2-star">★</span><div class="ab2-txt"><strong>ISO 9001:2015</strong><span>Quality Certified</span></div></div>
        <div class="about-badge1"><div class="ab1-icon"><svg width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/></svg></div><div class="ab1-txt"><strong>18,000+</strong><span>Happy Patients</span></div></div>
      </div>
      <div data-aos="right">
        <span class="label label-teal" style="display:block;margin-bottom:12px">Why Elara Medical</span>
        <h2 class="disp-xl" style="margin-bottom:18px">Where <span class="gradient-text">Precision</span> Meets <em style="font-style:italic">Compassion</em></h2>
        <p class="body-lg" style="margin-bottom:16px">Founded to bridge the gap between UK patients and Istanbul's world-class medical talent, Elara Medical has spent over a decade building trusted partnerships with the city's finest JCI-accredited hospitals.</p>
        <p class="body-lg" style="margin-bottom:24px">Every patient journey is supported by our dedicated UK-based team — available before your departure, throughout your procedure, and during every stage of your recovery.</p>
        <div class="about-features">
          <div class="af" data-aos="up"><div class="af-icon">🛡</div><div class="af-txt"><strong>Board-Certified Surgeons Only</strong><span>Every surgeon personally vetted by our clinical advisory panel with international accreditations</span></div></div>
          <div class="af" data-aos="up"><div class="af-icon">🕐</div><div class="af-txt"><strong>24/7 Patient Care Team</strong><span>Our UK team is reachable around the clock — you are never left without support</span></div></div>
          <div class="af" data-aos="up"><div class="af-icon">✈</div><div class="af-txt"><strong>Truly All-Inclusive Packages</strong><span>Flights guidance, 4-star hotel, transfers, medications and 12-month aftercare included</span></div></div>
          <div class="af" data-aos="up"><div class="af-icon">💷</div><div class="af-txt"><strong>Price-Match Guarantee</strong><span>We match any like-for-like quote from a verified Istanbul clinic partner</span></div></div>
        </div>
        <div style="display:flex;gap:12px;flex-wrap:wrap;margin-top:8px">
          <a href="<?php echo esc_url(elara_page_url('about-us')); ?>" class="btn btn-primary btn-lg">Discover Our Story</a>
          <a href="<?php echo esc_url(elara_page_url('about-us')); ?>" class="btn btn-outline btn-lg">Meet Our Surgeons</a>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- TREATMENTS -->
<section class="sec">
  <div class="container">
    <div class="sh center" data-aos="up" style="margin-bottom:52px">
      <span class="label label-teal">Our Treatments</span>
      <h2 class="disp-xl">Everything You Need, <em style="font-style:italic">All in One Place</em></h2>
      <p class="body-lg">World-class procedures across five specialties — each guided every step of the way by Elara Medical.</p>
    </div>
    <div class="treatment-cards">
      <a href="<?php echo esc_url(elara_page_url('hair-transplant')); ?>" class="tc" data-aos="up">
        <div class="tc-img"><img src="https://images.unsplash.com/photo-1503951914875-452162b0f3f1?w=500&q=80" alt="Hair Transplant" loading="lazy"></div>
        <div class="tc-overlay"></div>
        <div class="tc-body"><div class="tc-tag">Most Popular</div><div class="tc-title">Hair Transplant</div><div class="tc-price">From <strong>£1,499</strong> all-inclusive</div><div class="tc-link">FUE · DHI · Sapphire <svg fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24" width="14" height="14"><path d="M5 12h14M12 5l7 7-7 7"/></svg></div></div>
        <div class="tc-hover-bar"></div>
      </a>
      <a href="<?php echo esc_url(elara_page_url('cosmetic-surgery')); ?>" class="tc" data-aos="up">
        <div class="tc-img"><img src="https://images.unsplash.com/photo-1512290923902-8a9f81dc236c?w=500&q=80" alt="Cosmetic Surgery" loading="lazy"></div>
        <div class="tc-overlay"></div>
        <div class="tc-body"><div class="tc-title">Cosmetic Surgery</div><div class="tc-price">From <strong>£1,800</strong> all-inclusive</div><div class="tc-link">Face · Breast · Body <svg fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24" width="14" height="14"><path d="M5 12h14M12 5l7 7-7 7"/></svg></div></div>
        <div class="tc-hover-bar"></div>
      </a>
      <a href="<?php echo esc_url(elara_page_url('dental-treatments')); ?>" class="tc" data-aos="up">
        <div class="tc-img"><img src="https://images.unsplash.com/photo-1606811841689-23dfddce3e95?w=500&q=80" alt="Dental Treatments" loading="lazy"></div>
        <div class="tc-overlay"></div>
        <div class="tc-body"><div class="tc-tag" style="background:var(--teal)">New Packages</div><div class="tc-title">Dental Treatments</div><div class="tc-price">From <strong>£149</strong> per tooth</div><div class="tc-link">Implants · Veneers · Smile <svg fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24" width="14" height="14"><path d="M5 12h14M12 5l7 7-7 7"/></svg></div></div>
        <div class="tc-hover-bar"></div>
      </a>
      <a href="<?php echo esc_url(elara_page_url('weight-loss')); ?>" class="tc" data-aos="up">
        <div class="tc-img"><img src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=500&q=80" alt="Weight Loss Surgery" loading="lazy"></div>
        <div class="tc-overlay"></div>
        <div class="tc-body"><div class="tc-title">Weight Loss Surgery</div><div class="tc-price">From <strong>£2,800</strong> all-inclusive</div><div class="tc-link">Sleeve · Bypass · Balloon <svg fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24" width="14" height="14"><path d="M5 12h14M12 5l7 7-7 7"/></svg></div></div>
        <div class="tc-hover-bar"></div>
      </a>
    </div>
    <div style="text-align:center;margin-top:32px" data-aos="up">
      <a href="<?php echo esc_url(elara_page_url('eye-treatments')); ?>" class="btn btn-outline btn-lg">Also: Eye Treatments (LASIK, SMILE, ICL) →</a>
    </div>
  </div>
</section>

<!-- BEFORE AFTER -->
<section class="ba-section">
  <div class="container">
    <div class="sh center" style="max-width:640px;margin:0 auto 40px" data-aos="up">
      <span class="label label-white" style="display:block;margin-bottom:10px">Real Results</span>
      <h2 class="disp-xl" style="color:#fff">Transformations That <em style="font-style:italic">Speak for Themselves</em></h2>
      <p style="color:rgba(255,255,255,.55);font-size:.97rem">Every photo represents a real Elara Medical patient. No filters, no editing.</p>
    </div>
    <div class="ba-filter-row" data-aos="up">
      <button class="baf on" data-f="all">All</button>
      <button class="baf" data-f="hair">Hair</button>
      <button class="baf" data-f="face">Face</button>
      <button class="baf" data-f="dental">Dental</button>
      <button class="baf" data-f="body">Body</button>
    </div>
    <div class="ba-grid">
      <div class="ba-card" data-cat="hair" data-aos="up"><div class="ba-imgs"><div class="ba-side"><img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&q=70" alt="Before hair transplant" loading="lazy"><span class="ba-lbl">Before</span></div><div class="ba-side"><img src="https://images.unsplash.com/photo-1560250097-0b93528c311a?w=300&q=70" alt="After hair transplant" loading="lazy"><span class="ba-lbl">After</span></div></div><div class="ba-meta"><strong>FUE Hair Transplant</strong><span>3,800 grafts · 12 months · Manchester</span></div></div>
      <div class="ba-card" data-cat="face" data-aos="up"><div class="ba-imgs"><div class="ba-side"><img src="https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=300&q=70" alt="Before rhinoplasty" loading="lazy"><span class="ba-lbl">Before</span></div><div class="ba-side"><img src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&q=70" alt="After rhinoplasty" loading="lazy"><span class="ba-lbl">After</span></div></div><div class="ba-meta"><strong>Rhinoplasty</strong><span>Dorsal refinement · 9 months · London</span></div></div>
      <div class="ba-card" data-cat="dental" data-aos="up"><div class="ba-imgs"><div class="ba-side"><img src="https://images.unsplash.com/photo-1606811841689-23dfddce3e95?w=300&q=70" alt="Before dental" loading="lazy"><span class="ba-lbl">Before</span></div><div class="ba-side"><img src="https://images.unsplash.com/photo-1597764690523-9bda3bde0c64?w=300&q=70" alt="After Hollywood Smile" loading="lazy"><span class="ba-lbl">After</span></div></div><div class="ba-meta"><strong>Hollywood Smile</strong><span>20 porcelain veneers · 7 days · Birmingham</span></div></div>
      <div class="ba-card" data-cat="hair" data-aos="up"><div class="ba-imgs"><div class="ba-side"><img src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&q=70" alt="Before DHI" loading="lazy"><span class="ba-lbl">Before</span></div><div class="ba-side"><img src="https://images.unsplash.com/photo-1503951914875-452162b0f3f1?w=300&q=70" alt="After DHI" loading="lazy"><span class="ba-lbl">After</span></div></div><div class="ba-meta"><strong>DHI Hair Transplant</strong><span>4,200 grafts · 14 months · Leeds</span></div></div>
      <div class="ba-card" data-cat="body" data-aos="up"><div class="ba-imgs"><div class="ba-side"><img src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=300&q=70" alt="Before body" loading="lazy"><span class="ba-lbl">Before</span></div><div class="ba-side"><img src="https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=300&q=70" alt="After body" loading="lazy"><span class="ba-lbl">After</span></div></div><div class="ba-meta"><strong>Tummy Tuck + Lipo</strong><span>Combined procedure · 5 months · Bristol</span></div></div>
      <div class="ba-card" data-cat="face" data-aos="up"><div class="ba-imgs"><div class="ba-side"><img src="https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=300&q=70" alt="Before facelift" loading="lazy"><span class="ba-lbl">Before</span></div><div class="ba-side"><img src="https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb?w=300&q=70" alt="After facelift" loading="lazy"><span class="ba-lbl">After</span></div></div><div class="ba-meta"><strong>Facelift + Eyelid Surgery</strong><span>8 months post-op · Edinburgh</span></div></div>
    </div>
    <div style="text-align:center;margin-top:44px" data-aos="up">
      <a href="<?php echo esc_url(elara_page_url('patient-stories')); ?>" class="btn btn-outline-white btn-lg">View Full Gallery →</a>
    </div>
  </div>
</section>

<!-- PROCESS -->
<section class="sec">
  <div class="container">
    <div class="sh center" data-aos="up" style="margin-bottom:52px">
      <span class="label label-teal">Your Journey</span>
      <h2 class="disp-xl">Five Simple Steps to <em style="font-style:italic">Your New You</em></h2>
      <p>We handle every detail from first contact to final follow-up. All you need to do is arrive.</p>
    </div>
    <div class="process-steps">
      <div class="ps" data-aos="up"><div class="ps-circle"><span>🗓</span><div class="ps-n">1</div></div><h4>Free Consultation</h4><p>Speak with a specialist advisor, discuss your goals and receive a personalised treatment plan.</p></div>
      <div class="ps" data-aos="up"><div class="ps-circle"><span>📋</span><div class="ps-n">2</div></div><h4>Pre-Op Planning</h4><p>Medical screening, surgeon assignment, package confirmation and travel itinerary arranged.</p></div>
      <div class="ps" data-aos="up"><div class="ps-circle"><span>✈</span><div class="ps-n">3</div></div><h4>Travel &amp; Arrival</h4><p>VIP airport transfer, hotel check-in and pre-operative assessment — all included.</p></div>
      <div class="ps" data-aos="up"><div class="ps-circle"><span>🏥</span><div class="ps-n">4</div></div><h4>Your Procedure</h4><p>Treatment at a JCI-accredited hospital by your assigned board-certified specialist.</p></div>
      <div class="ps" data-aos="up"><div class="ps-circle"><span>💬</span><div class="ps-n">5</div></div><h4>Aftercare &amp; Results</h4><p>UK aftercare team checks in from week one right through to your final results.</p></div>
    </div>
  </div>
</section>

<!-- TESTIMONIALS -->
<section class="sec bg-off">
  <div class="container">
    <div class="sh center" data-aos="up" style="margin-bottom:48px">
      <span class="label label-teal">Patient Stories</span>
      <h2 class="disp-xl">Voices of Real <em style="font-style:italic">Transformations</em></h2>
      <p>Unedited, verified reviews from real Elara Medical patients across the UK.</p>
    </div>
    <div class="test-wrap" data-aos="fade">
      <div class="test-track" id="testTrack">
        <div class="tcard"><div class="tc-stars">★★★★★</div><p class="tc-quote">I'd avoided booking for years out of fear. The Elara team eliminated every concern. My FUE result at 11 months genuinely changed my life.</p><div class="tc-author"><div class="tc-av">JT</div><div><span class="tc-name">James T.</span><span class="tc-info">Manchester · FUE Hair Transplant</span><span class="tc-verified">✓ Verified Trustpilot Review</span></div></div></div>
        <div class="tcard"><div class="tc-stars">★★★★★</div><p class="tc-quote">As a nurse, I researched every aspect before committing. Elara exceeded every standard I checked. My rhinoplasty is exactly what we planned — natural and refined.</p><div class="tc-author"><div class="tc-av">SM</div><div><span class="tc-name">Sarah M.</span><span class="tc-info">London · Rhinoplasty</span><span class="tc-verified">✓ Verified Google Review</span></div></div></div>
        <div class="tcard"><div class="tc-stars">★★★★★</div><p class="tc-quote">Six implants for less than one UK implant. I keep telling people and they don't believe me. The quality was outstanding. Elara organised every single detail perfectly.</p><div class="tc-author"><div class="tc-av">DK</div><div><span class="tc-name">David K.</span><span class="tc-info">Birmingham · Dental Implants</span><span class="tc-verified">✓ Verified Trustpilot Review</span></div></div></div>
        <div class="tcard"><div class="tc-stars">★★★★★</div><p class="tc-quote">I felt completely safe throughout. The UK liaison called me every day of recovery. My result is everything I asked for — genuinely five-star in every way.</p><div class="tc-author"><div class="tc-av">ER</div><div><span class="tc-name">Emma R.</span><span class="tc-info">Edinburgh · Breast Augmentation</span><span class="tc-verified">✓ Verified Trustpilot Review</span></div></div></div>
        <div class="tcard"><div class="tc-stars">★★★★★</div><p class="tc-quote">I lost 4.5 stone in 8 months after my gastric sleeve. The whole process — from consultation to surgery to recovery — was handled impeccably by the Elara team.</p><div class="tc-author"><div class="tc-av">MP</div><div><span class="tc-name">Michael P.</span><span class="tc-info">Leeds · Gastric Sleeve</span><span class="tc-verified">✓ Verified Google Review</span></div></div></div>
      </div>
    </div>
    <div class="carousel-nav">
      <button class="cn-btn" id="tPrev"><svg viewBox="0 0 24 24"><polyline points="15 18 9 12 15 6"/></svg></button>
      <div class="cn-dots" id="tDots"></div>
      <button class="cn-btn" id="tNext"><svg viewBox="0 0 24 24"><polyline points="9 18 15 12 9 6"/></svg></button>
    </div>
  </div>
</section>

<!-- ACCREDITATIONS -->
<section class="sec-sm">
  <div class="container">
    <div class="sh center" style="margin-bottom:36px" data-aos="up">
      <span class="label label-teal">Trust &amp; Accreditation</span>
      <h2 class="disp-lg">Standards You Can Count On</h2>
    </div>
    <div class="accred-grid" data-aos="up">
      <div class="accred-card"><div class="accred-icon">🏆</div><div class="accred-name">ISO 9001:2015</div><div class="accred-desc">Internationally certified quality management</div></div>
      <div class="accred-card"><div class="accred-icon">🏥</div><div class="accred-name">JCI Partner</div><div class="accred-desc">Joint Commission International accreditation</div></div>
      <div class="accred-card"><div class="accred-icon">⭐</div><div class="accred-name">Trustpilot 4.9</div><div class="accred-desc">Excellent rating, 3,200+ verified reviews</div></div>
      <div class="accred-card"><div class="accred-icon">🇬🇧</div><div class="accred-name">UK Registered</div><div class="accred-desc">England &amp; Wales registered with full consumer protection</div></div>
      <div class="accred-card"><div class="accred-icon">🔒</div><div class="accred-name">ICO Registered</div><div class="accred-desc">Full GDPR compliance and data protection</div></div>
    </div>
  </div>
</section>

<!-- BLOG PREVIEW -->
<section class="sec bg-off">
  <div class="container">
    <div style="display:flex;justify-content:space-between;align-items:flex-end;margin-bottom:44px;flex-wrap:wrap;gap:16px" data-aos="up">
      <div class="sh"><span class="label label-teal">Knowledge Hub</span><h2 class="disp-xl">Expert Guides &amp; <em style="font-style:italic">Patient Resources</em></h2></div>
      <a href="<?php echo esc_url(elara_page_url('blog')); ?>" class="btn btn-outline">View All Articles →</a>
    </div>
    <div class="blog-grid" data-aos="fade">
      <div class="blog-card blog-featured"><div class="blog-img"><img src="https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=600&q=80" alt="FUE vs DHI" loading="lazy"></div><div class="blog-body"><span class="blog-cat">Hair Transplant</span><a href="<?php echo esc_url(elara_page_url('blog')); ?>" class="blog-title">FUE vs DHI Hair Transplant: The Definitive 2025 Guide for UK Patients</a><p class="blog-excerpt">A comprehensive comparison of the two leading techniques — graft survival, density outcomes, recovery time and which suits your hair loss pattern.</p><div class="blog-meta"><span>8 min read</span><span class="blog-meta-sep">·</span><span>March 2025</span></div></div></div>
      <div class="blog-card"><div class="blog-img"><img src="https://images.unsplash.com/photo-1606811841689-23dfddce3e95?w=400&q=80" alt="Hollywood Smile" loading="lazy"></div><div class="blog-body"><span class="blog-cat">Dental</span><a href="<?php echo esc_url(elara_page_url('blog')); ?>" class="blog-title">Hollywood Smile in Istanbul: The 2025 Complete Guide</a><p class="blog-excerpt">Everything you need to know about achieving the perfect smile abroad.</p><div class="blog-meta"><span>6 min read</span></div></div></div>
      <div class="blog-card"><div class="blog-img"><img src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400&q=80" alt="Gastric Sleeve" loading="lazy"></div><div class="blog-body"><span class="blog-cat">Weight Loss</span><a href="<?php echo esc_url(elara_page_url('blog')); ?>" class="blog-title">Gastric Sleeve vs Gastric Bypass: Which Is Right for You?</a><p class="blog-excerpt">A candid comparison of the two most common bariatric procedures.</p><div class="blog-meta"><span>9 min read</span></div></div></div>
    </div>
  </div>
</section>

<!-- FAQ PREVIEW -->
<section class="sec">
  <div class="container">
    <div class="faq-layout">
      <div data-aos="left">
        <span class="label label-teal" style="display:block;margin-bottom:12px">FAQs</span>
        <h2 class="disp-xl">Honest Answers to <em style="font-style:italic">Your Questions</em></h2>
        <p class="body-lg" style="margin-bottom:24px">We believe transparency builds trust. Here are the questions we hear every week — answered without spin.</p>
        <div class="faq-cta-box">
          <h4>Can't find your answer?</h4>
          <p>Our specialist advisors are available 7 days a week.</p>
          <a href="#" class="btn btn-primary open-modal">Chat With a Specialist</a>
        </div>
      </div>
      <div class="faq-list" data-aos="right">
        <div class="faq-item"><div class="faq-q">Is it safe to have surgery in Istanbul?<div class="faq-icon"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg></div></div><div class="faq-a">Istanbul's JCI-accredited hospitals meet the same international safety benchmarks as leading UK private hospitals. Our partner clinics undergo rigorous annual inspections, and every surgeon holds international board certification.</div></div>
        <div class="faq-item"><div class="faq-q">What is included in an all-inclusive package?<div class="faq-icon"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg></div></div><div class="faq-a">Your package includes the procedure, pre-operative medical tests, 4-star hotel accommodation, VIP airport transfers, personal coordinator, translation and post-operative medications. Flights and personal spending are the only exclusions.</div></div>
        <div class="faq-item"><div class="faq-q">How much will I save compared to UK prices?<div class="faq-icon"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg></div></div><div class="faq-a">Most patients save 50–75% versus equivalent UK private clinic pricing. A hair transplant that costs £8,000–£12,000 in London typically starts from £1,499 with Elara Medical — with full accommodation, transfers and aftercare included.</div></div>
        <div class="faq-item"><div class="faq-q">What if I experience complications?<div class="faq-icon"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg></div></div><div class="faq-a">All patients are covered by our comprehensive aftercare guarantee. In the rare event of complications, we coordinate with your surgeon, arrange follow-up, and in exceptional cases cover revision procedures at no cost.</div></div>
        <div class="faq-item"><div class="faq-q">When will I see my full results?<div class="faq-icon"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg></div></div><div class="faq-a">Hair transplants: full results at 12–14 months. Rhinoplasty: 6–12 months. Breast surgery: 6–8 weeks. Dental: immediate. Weight loss: ongoing over 12–24 months. Eye surgery: stable within 2–4 weeks.</div></div>
      </div>
    </div>
  </div>
</section>

<!-- CTA BANNER -->
<section class="cta-banner">
  <div class="container">
    <span class="label label-white" style="display:block;margin-bottom:14px" data-aos="up">Take the First Step</span>
    <h2 class="disp-xl" style="color:#fff" data-aos="up">Your Transformation Is <em style="font-style:italic">One Call Away</em></h2>
    <p data-aos="up">Join over 18,000 patients who trusted Elara Medical. Your free consultation is 20 minutes, completely confidential, and carries zero obligation.</p>
    <div class="cta-btns" data-aos="up">
      <a href="#" class="btn btn-gold btn-xl open-modal">🗓 Book Free Consultation</a>
      <a href="tel:<?php echo esc_attr(str_replace(' ','',elara_phone())); ?>" class="btn btn-outline-white btn-xl">📞 <?php echo esc_html(elara_phone()); ?></a>
    </div>
    <p class="cta-note">Available Monday–Saturday · 9am–7pm · Same-day callbacks · No obligation</p>
  </div>
</section>

<?php get_footer();
