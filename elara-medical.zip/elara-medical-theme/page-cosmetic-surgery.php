<?php /* Template Name: Cosmetic Surgery */ get_header(); ?>
<div class="page-hero"><div class="container"><div>
<div class="ph-breadcrumb"><a href="<?php echo home_url('/'); ?>">Home</a><span>›</span><span>Cosmetic Surgery</span></div>
<h1 class="disp-xl ph-h1">Cosmetic Surgery in Istanbul — <em style="font-style:italic">Precision. Artistry. Results.</em></h1>
<p class="ph-sub">From rhinoplasty to body contouring — our board-certified plastic surgeons deliver outstanding outcomes in Istanbul's finest accredited hospitals.</p>
<div class="ph-ctas"><a href="#" class="btn btn-gold btn-lg open-modal">Free Consultation</a><a href="<?php echo esc_url(elara_page_url('patient-stories')); ?>" class="btn btn-outline-white btn-lg">View Before &amp; After</a></div>
</div></div></div>
<section class="sec"><div class="container">
<div class="sh" data-aos="up" style="margin-bottom:40px"><span class="label label-teal">Facial Surgery</span><h2 class="disp-xl">Your Face, <em style="font-style:italic">Perfectly Refined</em></h2><p>Every facial procedure is designed around your unique bone structure — delivering subtle, sophisticated enhancements that look natural.</p></div>
<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:20px;margin-bottom:60px">
<div class="card" data-aos="up" style="padding:0"><div style="height:180px;overflow:hidden"><img src="https://images.unsplash.com/photo-1614859324967-bdf413c35a08?w=400&q=80" alt="Rhinoplasty" loading="lazy" style="width:100%;height:100%;object-fit:cover"></div><div style="padding:18px"><h3 style="font-family:var(--font-display);font-size:1.15rem;font-weight:600;color:var(--dark);margin-bottom:6px">Rhinoplasty</h3><p style="font-size:.82rem;color:var(--text2);line-height:1.6;margin-bottom:10px">Nose reshaping, hump reduction and tip refinement by Istanbul's leading rhinoplasty specialists.</p><div style="font-size:.8rem;color:var(--teal);font-weight:700">From £2,200</div></div></div>
<div class="card" data-aos="up" style="padding:0"><div style="height:180px;overflow:hidden"><img src="https://images.unsplash.com/photo-1512290923902-8a9f81dc236c?w=400&q=80" alt="Facelift" loading="lazy" style="width:100%;height:100%;object-fit:cover"></div><div style="padding:18px"><h3 style="font-family:var(--font-display);font-size:1.15rem;font-weight:600;color:var(--dark);margin-bottom:6px">Facelift</h3><p style="font-size:.82rem;color:var(--text2);line-height:1.6;margin-bottom:10px">Restore facial definition and reverse the effects of ageing with natural, well-rested results.</p><div style="font-size:.8rem;color:var(--teal);font-weight:700">From £3,800</div></div></div>
<div class="card" data-aos="up" style="padding:0"><div style="height:180px;overflow:hidden"><img src="https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=400&q=80" alt="Eyelid Surgery" loading="lazy" style="width:100%;height:100%;object-fit:cover"></div><div style="padding:18px"><h3 style="font-family:var(--font-display);font-size:1.15rem;font-weight:600;color:var(--dark);margin-bottom:6px">Eyelid Surgery</h3><p style="font-size:.82rem;color:var(--text2);line-height:1.6;margin-bottom:10px">Upper and lower blepharoplasty to restore a bright, open, youthful eye area.</p><div style="font-size:.8rem;color:var(--teal);font-weight:700">From £1,800</div></div></div>
<div class="card" data-aos="up" style="padding:0"><div style="height:180px;overflow:hidden"><img src="https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb?w=400&q=80" alt="Brow Lift" loading="lazy" style="width:100%;height:100%;object-fit:cover"></div><div style="padding:18px"><h3 style="font-family:var(--font-display);font-size:1.15rem;font-weight:600;color:var(--dark);margin-bottom:6px">Brow Lift</h3><p style="font-size:.82rem;color:var(--text2);line-height:1.6;margin-bottom:10px">Elevate the brow position for a refreshed, energised appearance.</p><div style="font-size:.8rem;color:var(--teal);font-weight:700">From £1,600</div></div></div>
</div>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:48px">
<div><div class="sh" data-aos="up" style="margin-bottom:32px"><span class="label label-teal">Breast Surgery</span><h2 class="disp-lg">Feminine Confidence, <em style="font-style:italic">Beautifully Achieved</em></h2></div>
<div style="display:flex;flex-direction:column;gap:12px">
<div class="af" data-aos="up"><div class="af-icon">👙</div><div class="af-txt"><strong>Breast Augmentation — From £2,800</strong><span>All implant sizes. Anatomical and round options with high-cohesive gel.</span></div></div>
<div class="af" data-aos="up"><div class="af-icon">⬆️</div><div class="af-txt"><strong>Breast Lift — From £2,400</strong><span>Mastopexy to restore a youthful, elevated breast position.</span></div></div>
<div class="af" data-aos="up"><div class="af-icon">⬇️</div><div class="af-txt"><strong>Breast Reduction — From £2,600</strong><span>Relieve discomfort and achieve a more proportionate silhouette.</span></div></div>
<div class="af" data-aos="up"><div class="af-icon">🔄</div><div class="af-txt"><strong>Gynecomastia — From £1,800</strong><span>Male breast reduction via liposuction and/or tissue excision.</span></div></div>
</div></div>
<div><div class="sh" data-aos="up" style="margin-bottom:32px"><span class="label label-teal">Body Surgery</span><h2 class="disp-lg">The Body You've <em style="font-style:italic">Always Deserved</em></h2></div>
<div style="display:flex;flex-direction:column;gap:12px">
<div class="af" data-aos="up"><div class="af-icon">💧</div><div class="af-txt"><strong>Liposuction — From £1,800</strong><span>Precision fat removal from abdomen, flanks, thighs, arms and more.</span></div></div>
<div class="af" data-aos="up"><div class="af-icon">✂️</div><div class="af-txt"><strong>Tummy Tuck — From £3,200</strong><span>Full and mini abdominoplasty to remove excess skin and tighten muscles.</span></div></div>
<div class="af" data-aos="up"><div class="af-icon">🍑</div><div class="af-txt"><strong>Brazilian Butt Lift — From £3,400</strong><span>Natural fat transfer augmentation using your own body's fat.</span></div></div>
<div class="af" data-aos="up"><div class="af-icon">⭐</div><div class="af-txt"><strong>Mummy Makeover — From £5,200</strong><span>Combined breast and body package for post-pregnancy restoration.</span></div></div>
</div></div>
</div>
</div></section>
<section class="cta-banner"><div class="container"><h2 class="disp-xl" style="color:#fff">Ready to Transform?</h2><p style="color:rgba(255,255,255,.65);margin-bottom:32px">Book your free consultation and receive a personalised surgical plan.</p><div class="cta-btns"><a href="#" class="btn btn-gold btn-xl open-modal">Book Free Consultation</a></div></div></section>
<?php get_footer();
