<?php /* Template Name: Blog Hub */ get_header(); ?>
<div class="page-hero" style="padding:140px 0 60px"><div class="container"><div>
<div class="ph-breadcrumb"><a href="<?php echo home_url('/'); ?>">Home</a><span>›</span><span>Blog</span></div>
<h1 class="disp-xl ph-h1">The Elara Medical <em style="font-style:italic">Knowledge Hub</em></h1>
<p class="ph-sub">Expert guides, honest advice and patient resources — written by our clinical team to help you make fully informed decisions.</p>
</div></div></div>
<section class="sec"><div class="container">
<?php
$args = array('post_type'=>'post','posts_per_page'=>9,'post_status'=>'publish');
$posts = new WP_Query($args);
if($posts->have_posts()):
?>
<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:24px">
<?php while($posts->have_posts()): $posts->the_post(); ?>
<div class="blog-card" data-aos="up">
  <?php if(has_post_thumbnail()): ?>
  <div class="blog-img" style="height:200px"><a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('medium_large',['style'=>'width:100%;height:100%;object-fit:cover']); ?></a></div>
  <?php endif; ?>
  <div class="blog-body">
    <span class="blog-cat"><?php the_category(', '); ?></span>
    <a href="<?php the_permalink(); ?>" class="blog-title"><?php the_title(); ?></a>
    <p class="blog-excerpt"><?php echo wp_trim_words(get_the_excerpt(),18); ?></p>
    <div class="blog-meta"><span><?php echo get_the_date(); ?></span><span class="blog-meta-sep">·</span><span><?php echo ceil(str_word_count(strip_tags(get_the_content()))/200); ?> min read</span></div>
  </div>
</div>
<?php endwhile; wp_reset_postdata();
else: ?>
<div class="blog-grid">
<div class="blog-card blog-featured" data-aos="up"><div class="blog-img"><img src="https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=700&q=80" alt="FUE vs DHI" loading="lazy"></div><div class="blog-body"><span class="blog-cat">Hair Transplant</span><span class="blog-title">FUE vs DHI: The Definitive 2025 Guide for UK Patients</span><p class="blog-excerpt">A comprehensive comparison of the two leading hair transplant techniques — graft survival, density, recovery and which suits your pattern of hair loss.</p><div class="blog-meta"><span>8 min read</span><span class="blog-meta-sep">·</span><span>March 2025</span></div></div></div>
<div class="blog-card" data-aos="up"><div class="blog-img"><img src="https://images.unsplash.com/photo-1606811841689-23dfddce3e95?w=400&q=80" alt="Hollywood Smile" loading="lazy"></div><div class="blog-body"><span class="blog-cat">Dental</span><span class="blog-title">Hollywood Smile in Istanbul: The 2025 Guide</span><p class="blog-excerpt">Everything you need to know about achieving your perfect smile abroad.</p><div class="blog-meta"><span>6 min read</span></div></div></div>
<div class="blog-card" data-aos="up"><div class="blog-img"><img src="https://images.unsplash.com/photo-1614859324967-bdf413c35a08?w=400&q=80" alt="Rhinoplasty" loading="lazy"></div><div class="blog-body"><span class="blog-cat">Cosmetic Surgery</span><span class="blog-title">Is Rhinoplasty Abroad Safe? What UK Patients Need to Know</span><p class="blog-excerpt">An honest assessment of the safety record and what questions to ask before booking.</p><div class="blog-meta"><span>7 min read</span></div></div></div>
<div class="blog-card" data-aos="up"><div class="blog-img"><img src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400&q=80" alt="Weight Loss" loading="lazy"></div><div class="blog-body"><span class="blog-cat">Weight Loss</span><span class="blog-title">Gastric Sleeve vs Gastric Bypass: Which Is Right for You?</span><p class="blog-excerpt">A candid comparison of the two most common bariatric procedures.</p><div class="blog-meta"><span>9 min read</span></div></div></div>
<div class="blog-card" data-aos="up"><div class="blog-img"><img src="https://images.unsplash.com/photo-1527838832700-5059252407fa?w=400&q=80" alt="Istanbul" loading="lazy"></div><div class="blog-body"><span class="blog-cat">Travel Guide</span><span class="blog-title">Your First Trip to Istanbul for Surgery: A Complete Practical Guide</span><p class="blog-excerpt">Flights, hotels, what to pack — everything a first-time medical traveller needs to know.</p><div class="blog-meta"><span>10 min read</span></div></div></div>
<div class="blog-card" data-aos="up"><div class="blog-img"><img src="https://images.unsplash.com/photo-1503951914875-452162b0f3f1?w=400&q=80" alt="Hair Transplant Cost" loading="lazy"></div><div class="blog-body"><span class="blog-cat">Hair Transplant</span><span class="blog-title">How Much Does a Hair Transplant Really Cost in 2025?</span><p class="blog-excerpt">A full breakdown of all costs — procedure, accommodation, flights and aftercare.</p><div class="blog-meta"><span>7 min read</span></div></div></div>
</div>
<?php endif; ?>
</div></section>
<?php get_footer();
